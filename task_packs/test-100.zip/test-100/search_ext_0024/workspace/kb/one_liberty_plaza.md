# One Liberty Plaza

One Liberty Plaza, formerly the U.S. Steel Building, is a skyscraper in Lower Manhattan, in New York City, at the location of the former Singer Building (tallest structure ever dismantled) and the former City Investing Building.  One Liberty Plaza is currently owned and operated by Brookfield Office Properties.  The building is 743 ft tall and has 54 floors.  It was completed in 1973.  At 2300000 sqft , each floor offers almost 1 acre of office space, making it one of the largest office buildings in New York.
