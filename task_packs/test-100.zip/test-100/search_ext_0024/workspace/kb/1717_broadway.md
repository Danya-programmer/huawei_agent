# 1717 Broadway

1717 Broadway is a skyscraper located in Manhattan, New York City, United States.  At 750 feet high, it is the tallest hotel in North America.  The building contains two hotels, the Courtyard New York Manhattan/Central Park and the Residence Inn New York Manhattan/Central Park, with a total of 639 rooms.  The glass-clad building is located on the Northwest corner of 54th Street and Broadway.
