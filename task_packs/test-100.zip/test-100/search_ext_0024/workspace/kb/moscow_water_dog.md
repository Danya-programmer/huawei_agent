# Moscow Water Dog

The Moscow Water Dog, also known as the Moscow Diver, Moscow Retriever or Moskovsky Vodolaz, is a little-known dog breed derived from the Newfoundland, Caucasian Shepherd Dog and East European Shepherd.  It is now extinct, but was used in the development of the  Black Russian Terrier.  The Moscow Water Dog was produced only by the Red Star Kennels, the state operated organization chartered to provide working dogs for the armed services.
