# Spanish Water Dog

The Spanish Water Dog (perro de agua español ) breed dates back several hundred years and has its origins most likely in Turkey from where it was imported into Spain as a general purpose sheepdog and guard.  It is also used sometimes as a gundog, and is skilled at retrieval from water.  The SWD has strong genetic links to other ancient water breeds such as the Portuguese Water Dog, the French Barbet and the Irish Water Spaniel.
