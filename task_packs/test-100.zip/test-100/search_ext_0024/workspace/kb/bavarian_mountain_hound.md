# Bavarian Mountain Hound

The Bavarian Mountain Hound (German = "Bayerischer Gebirgsschweißhund") is a breed of dog from Germany.  As a scent hound, it has been used in Germany since the early 20th century to trail wounded game.  It is a cross between the Bavarian Hound and the Hanover Hound.
