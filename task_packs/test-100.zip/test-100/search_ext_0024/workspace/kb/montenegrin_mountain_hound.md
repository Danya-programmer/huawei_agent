# Montenegrin Mountain Hound

The Montenegrin Mountain Hound is a rare dog breed from the mountain regions across the Balkans.  Black and tan, with a smooth coat, the Montenegrin Mountain Hound was called "Black Hound" in the past.  The breed is of the same origin as the other Balkan hounds.  He stands 18 to high and weighs 44 to .  The breed is used to hunt fox, hare, and small game, occasionally hunting larger animals such as deer or even wild boar.
