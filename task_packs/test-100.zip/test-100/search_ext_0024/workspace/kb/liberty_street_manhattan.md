# Liberty Street (Manhattan)

Liberty Street is a street in New York City that stretches east-west from the middle of Lower Manhattan almost to the East River.  It borders such sites as One Chase Manhattan Plaza, the Federal Reserve Bank of New York, One Liberty Plaza, Liberty Plaza Park, the World Trade Center site, the World Financial Center, Gateway Plaza, Liberty Park, and the North Cove marina.  A FDNY Firehouse, Engine Co. # 10 and Ladder Co. # 10, is located at 124 Liberty Street, directly across from Ground Zero.
