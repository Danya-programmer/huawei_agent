# Bo (dog)

Bo (born October 9, 2008) is a pet dog of the Obama family, the former First Family of the United States.  Bo is a male Portuguese Water Dog.  President Barack Obama and his family were given the dog as a gift after months of speculation about the breed and identity of their future pet.  The final choice was made in part because Malia Obama's allergies dictated a need for a hypoallergenic breed.  Bo has occasionally been called "First Dog".  In August 2013, Bo was joined by Sunny, a female dog of the same breed.
