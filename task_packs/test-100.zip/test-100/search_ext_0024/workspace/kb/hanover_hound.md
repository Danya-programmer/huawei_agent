# Hanover Hound

The Hanover Hound is a breed of dog sometimes referred to as a Hanoverian Hound.  It is a hunting and tracking dog descended from bloodhounds of medieval times.  It was first introduced into France in the 1980s and is still a very rare breed.  It was cross-bred with the Bavarian Hound which gave rise to the Bavarian Mountain Hound.
