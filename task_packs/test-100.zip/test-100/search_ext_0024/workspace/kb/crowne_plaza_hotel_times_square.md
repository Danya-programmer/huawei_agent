# Crowne Plaza Hotel, Times Square

Crowne Plaza Times Square is a 795-room hotel situated in the Times Square area of New York City's midtown Manhattan, located at 1605 Broadway, between 48th and 49th Streets.  West 48th Street, and West 49th Street.  At 480 feet (146 meters), with 46 floors, it is the 94th tallest hotel in the world, the 29th tallest hotel in the United States, and the 15th-tallest hotel in New York City.  The hotel was completed in 1989 and opened in 1990.
