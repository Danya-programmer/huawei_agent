# Solow Building

The Solow Building, located at 9 West 57th Street, is a Manhattan skyscraper built in 1974 and designed by Gordon Bunshaft of Skidmore, Owings and Merrill.  It is located just west of Fifth Avenue between the 57th and 58th Street, next to the Bergdorf Goodman department store and the Plaza Hotel.  At 50 stories and 689 ft in height, the building's only nearby competitor by height is the GM Building, located one block north and east.  Floors above the 23rd floor offer an unobstructed view of northern Manhattan and a complete view of Central Park and The Plaza Hotel.
