# Mountain Cur

The Mountain Cur is a type of working dog that is bred specifically for treeing and trailing small game, like squirrel and raccoons.  They are also used for hunting and baying big game like bear and wild boar as well as being an all-purpose farm dog.  Curs are a member of the Hound group, and the Mountain Cur is one of several varieties of cur.  It can also be used as a water dog.  Mainly bred in Ohio, Kentucky, Virginia, and Tennessee, it has been registered with the United Kennel Club since 1998.  The Mountain Cur Breeder's Association was formed in 1957.
