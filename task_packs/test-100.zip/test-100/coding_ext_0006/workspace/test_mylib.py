import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert find_rect_num(4) == 20
        assert find_rect_num(5) == 30
        assert find_rect_num(6) == 42

if __name__ == '__main__':
    unittest.main()
