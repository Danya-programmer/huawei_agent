def find_rect_num(n):
  return (n*(n + 1)) + 1  # bug
