# Muhammad Iqbal

Allama Iqbal ( ) (November 9, 1877 – April 21, 1938), widely known as Muhammad Iqbal, was a poet, philosopher, and politician, as well as an academic, barrister and scholar in British India who is widely regarded as having inspired the Pakistan Movement.  He is called the "Spiritual Father of Pakistan " He is considered one of the most important figures in Urdu literature, with literary work in both Urdu and Persian.
