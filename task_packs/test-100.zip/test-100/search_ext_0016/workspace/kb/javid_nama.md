# Javid Nama

The Javid Nama (Persian: جاوید نامہ‎ ‎ ), or Book of Eternity, is a Persian book of poetry written by Allama Muhammad Iqbal and published in 1932.  It is considered to be one of the masterpieces of Iqbal.  It is inspired by Dante's "Divine Comedy", and just as Dante's guide was Virgil, Iqbal is guided by Moulana Rumi.  Both of them visit different spheres in the heavens coming across different people.  Iqbal uses the pseudonym Zinda Rud for himself in this book.
