# Zinda Rood

Zinda Rood is a 4 volume biographical work of Justice Javed Iqbal on his father Muhammad Iqbal, a Muslim poet-philosopher.  Zinda Rood is translated as 'living stream of life', a pseudonym Muhammad Iqbal used for himself in his persian Masnavi "Javid Nama".
