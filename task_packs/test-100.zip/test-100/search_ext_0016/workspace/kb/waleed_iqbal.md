# Waleed Iqbal

Waleed Iqbal is a Pakistani politician, lawyer and law professor.  He is the grandson of poet and politician Muhammad Iqbal, and the son of philosopher and former judge Javed Iqbal and judge Nasira Iqbal.
