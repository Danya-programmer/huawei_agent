# Rabotnitsa

Rabotnitsa (Russian: Работница ; English: The Woman Worker ) is a women's journal, published in the Soviet Union and Russia and one of the oldest Russian magazines for women and families.  Founded in 1914, and first published on Women's Day, it is the first socialist women's journal, and the most politically left of the women's periodicals.  While the journal's beginnings are attributed to Lenin and several women who were close to him, he did not contribute to the first seven issues.
