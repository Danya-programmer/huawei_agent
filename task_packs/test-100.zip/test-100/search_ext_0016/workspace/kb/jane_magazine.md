# Jane (magazine)

Jane was an American magazine created to appeal to the women who grew up reading "Sassy Magazine"; Jane Pratt was the founding editor of each.  Its original target audience (pitched to advertisers) was aged 18–34, and was designed to appeal to women who did not like the typical women's magazine format.  Pratt originally intended the magazine to be named "Betty", but she was voted down by everyone else involved in the making of the magazine.
