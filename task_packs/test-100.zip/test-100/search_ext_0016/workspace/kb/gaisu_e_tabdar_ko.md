# Gaisu e Tabdar Ko

Gaisu e Tabdar Ko is a Urdu ghazal written by noted Urdu poet, Muhammad Iqbal.  It is the third Ghazal in the Ghazals part of 'Baal-e-Jibriel', a book of poetry by Dr. Muhammad Iqbal.
