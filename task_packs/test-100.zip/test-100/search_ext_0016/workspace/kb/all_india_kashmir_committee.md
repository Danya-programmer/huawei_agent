# All India Kashmir Committee

All India Kashmir Committee was set up by prominent Muslim leaders of India on July 25, 1931.  Muhammad Iqbal and a number of other leaders were invited by Mirza Bashir-ud-Din Mahmood Ahmad to form the committee.  Although orthodox press and historians attribute the formation of the Committee to Dr. Muhammad Iqbal.
