# Jane Cunningham Croly

Jane Cunningham Croly (December 19, 1829 – December 23, 1901) was an American author and journalist, better known by her pseudonym, Jennie June.  She was a pioneer author and editor of women's columns in leading newspapers and magazines in New York.  She founded the Sorosis club for women in New York in 1868 and in 1889 expanded it nationwide to the General Federation of Women's Clubs.  She also founded the Woman's Press Club of New York City.
