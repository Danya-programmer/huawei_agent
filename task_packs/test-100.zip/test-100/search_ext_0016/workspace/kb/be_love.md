# Be Love

Be Love is a Japanese manga magazine targeting women published by Kodansha.  It debuted in September 1980.  It is one of the leading manga magazines for adult women, the first of its kind, and was instrumental in the rising popularity of josei manga in the 1980s, which led to the creation of other magazines targeted at women such as "You" and "Big Comic for Lady".  As of 2003, "Be Love", like "You" and "Jour", published stories focussing on "the reality of everyday life" experienced by its readers.
