# List of magazines in Malaysia

The first women's magazine was published in Malaysia in 1932.  In the 2000s there were nearly fifty local titles addressing women in the country.  These magazines also include those having an Islamic perspective.  Some international women's magazines are also published in Malaysia.  One of them is "Elle Malaysia", which was first published in March 2014.  Another one, "Women’s Health", was started in April 2015.  Comic magazines and film magazines are also common in Malaysia.
