# Tolu-e-Islam (magazine)

Tolu-e-Islam is a historical, political, religious, cultural magazine of Muslims of British India and Pakistan.  In 1935, according to the instructions of Sir Muhammad Iqbal, Syed Nazeer Niazi initiated and edited a journal named after "Tulu'i Islam", a poem by Iqbal.  Niazi also dedicated the first edition of this journal to him.  For a long time Iqbal had wanted a journal to propagate his ideas and the aims and objective of the All-India Muslim League.
