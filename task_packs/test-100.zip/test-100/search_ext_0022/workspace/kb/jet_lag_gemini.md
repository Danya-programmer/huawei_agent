# Jet Lag Gemini

Jet Lag Gemini (wn as Jet Lag or JLG) was an American rock band.  Formed in 2004, they released their debut EP, Business, in the summer of 2006.  Their first full-length album, "Fire the Cannons" was released on January 22, 2008.  They had planned on releasing their currently untitled second album early 2010, which was rumored to be produced by Mark Hoppus of Blink 182.  Between 2010 and 2011 the band was dismantled.
