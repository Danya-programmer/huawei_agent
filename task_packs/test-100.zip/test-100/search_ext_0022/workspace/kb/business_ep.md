# Business (EP)

Business is the debut EP from New Jersey, rock band Jet Lag Gemini.  Recorded in Madison, NJ at Northshore Studios when two of the band members were still 15 years old, the EP was released June 6, 2006 on Doghouse Records.
