# Battle of Monmouth

The Battle of Monmouth was an American Revolutionary War battle fought on June 28, 1778, in Monmouth County, New Jersey.  The Continental Army under General George Washington attacked the rear of the British Army column commanded by Lieutenant General Sir Henry Clinton as they left Monmouth Court House (modern Freehold Borough).  It is also known as the Battle of Monmouth Courthouse.
