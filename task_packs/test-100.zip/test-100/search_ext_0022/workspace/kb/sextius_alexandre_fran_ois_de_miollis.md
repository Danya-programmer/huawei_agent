# Sextius Alexandre François de Miollis

"Sextius Alexandre François de Miollis"' (Aix, September 18, 1759 – Aix, June 18, 1828) was a French military officer serving in the American Revolutionary War, the French Revolutionary Wars, and the Napoleonic Wars.
