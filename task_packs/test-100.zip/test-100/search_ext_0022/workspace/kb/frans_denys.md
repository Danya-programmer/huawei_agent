# Frans Denys

Frans Denys (name variations: François de Nijs, François de Nis, François de Nys, François Denis, François Denys, François Dannys, François Nijs, Fransois Denies, Donys; first name also: Fransoos and Fransous) (c. 1610, Antwerp – 1670, Mantua), was a Flemish Baroque painter mainly of portraits.  After a successful career in Antwerp he became a court painter in Italy.
