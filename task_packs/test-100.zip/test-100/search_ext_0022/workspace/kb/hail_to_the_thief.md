# Hail to the Thief

Hail to the Thief is the sixth studio album by the English rock band Radiohead.  It was released on 9 June 2003, by Parlophone Records in the United Kingdom, and a day later by Capitol Records in the United States.  Following "Kid A" (2000) and "Amnesiac" (2001), which incorporated jazz, classical and electronic music influences, "Hail to the Thief" combines alternative rock instrumentation with drum machines, synthesisers, and digital manipulation.
