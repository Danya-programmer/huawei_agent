# COM LAG (2plus2isfive)

COM LAG (2plus2isfive) is the sixth compilation EP by the English rock band Radiohead, released in March 2004 in Japan and Australia.  It is collects many of the B-sides from the singles from their 2003 album "Hail to the Thief", along with some live tracks and remixes by Cristian Vogel and Four Tet.
