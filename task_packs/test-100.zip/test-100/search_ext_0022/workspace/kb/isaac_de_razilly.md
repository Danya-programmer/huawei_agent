# Isaac de Razilly

Isaac de Razilly (1587 – 1635) was a member of the French nobility appointed a knight of the Order of St. John of Jerusalem at the age of 18.  He was born at the Château d'Oiseaumelle in the Province of Touraine, France.  A member of the French navy, he served for many years during which he played an important role in the French colony of Acadia in New France.  He was the son of François de Razilly and Catherine de Villiers, brother of Claude de Razilly and François de Razilly.  Commandeur de la Commanderie de l'Ile Bouchard (Touraine)
