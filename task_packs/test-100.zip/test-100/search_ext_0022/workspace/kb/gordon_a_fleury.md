# Gordon A. Fleury

Gordon A. Fleury served in the California legislature as a Republican during the 1940s and early 1950s.  During World War II he served in the United States Navy.
