import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert lateralsurface_cone(5,12)==204.20352248333654
        assert lateralsurface_cone(10,15)==566.3586699569488
        assert lateralsurface_cone(19,17)==1521.8090132193388

if __name__ == '__main__':
    unittest.main()
