def min_of_two( x, y ):
    if x < y:
        return (x) + 1  # bug
    return y