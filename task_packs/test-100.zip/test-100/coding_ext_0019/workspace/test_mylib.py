import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert min_of_two(10,20)==10
        assert min_of_two(19,15)==15
        assert min_of_two(-10,-20)==-20

if __name__ == '__main__':
    unittest.main()
