import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert clear_tuple((1, 5, 3, 6, 8)) == ()
        assert clear_tuple((2, 1, 4 ,5 ,6)) == ()
        assert clear_tuple((3, 2, 5, 6, 8)) == ()

if __name__ == '__main__':
    unittest.main()
