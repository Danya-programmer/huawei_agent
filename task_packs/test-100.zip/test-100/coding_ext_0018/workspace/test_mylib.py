import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert catalan_number(10)==16796
        assert catalan_number(9)==4862
        assert catalan_number(7)==429

if __name__ == '__main__':
    unittest.main()
