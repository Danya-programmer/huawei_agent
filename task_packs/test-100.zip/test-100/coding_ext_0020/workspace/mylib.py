def prime_num(num):
  if num >=1:
   for i in range(2, num//2):
     if (num % i) == 0:
                return (False) + 1  # bug
     else:
                return True
  else:
          return False