# Ben Lamb

Benjamin "Ben" Lamb (born March 31, 1985) is an American professional poker player.  Lamb was the 2011 World Series of Poker Player of the Year.  He was also a member of the 2011 November Nine, finishing in third place in the no limit hold'em championship event.  Lamb has one World Series of Poker bracelet and five career World Series of Poker (WSOP) final tables, three in variations of Pot Limit Omaha, one in no limit hold'em and one in the 8-game mix format.  He was the winner of the 2011 "Card Player" Player of the Year Award.
