# Switchback (film)

Switchback is a 1997 American thriller film starring Dennis Quaid, Danny Glover, Jared Leto, Ted Levine, William Fichtner and R. Lee Ermey, set in Amarillo, Texas and moving through New Mexico and Southern Colorado.  It was written and directed by Jeb Stuart.
