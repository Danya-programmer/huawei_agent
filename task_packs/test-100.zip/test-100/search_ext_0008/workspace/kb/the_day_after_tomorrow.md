# The Day After Tomorrow

The Day After Tomorrow is a 2004 American science-fiction disaster film co-written, directed, and produced by Roland Emmerich and starring Dennis Quaid, Jake Gyllenhaal, Ian Holm, Emmy Rossum, and Sela Ward.  The film depicts catastrophic climatic effects following the disruption of the North Atlantic Ocean circulation in a series of extreme weather events that usher in global cooling and lead to a new ice age.  Filmed in Toronto and Montreal, it is the highest-grossing Hollywood film made in Canada (adjusted for inflation).
