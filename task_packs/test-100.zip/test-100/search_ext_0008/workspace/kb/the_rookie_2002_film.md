# The Rookie (2002 film)

The Rookie is a 2002 sports drama film directed by John Lee Hancock and produced by Walt Disney Pictures.  It is based on the true story of Jim Morris, who had a brief, but famous Major League Baseball career in 1999–2000.  The film stars Dennis Quaid, Rachel Griffiths, Jay Hernandez, and Brian Cox.
