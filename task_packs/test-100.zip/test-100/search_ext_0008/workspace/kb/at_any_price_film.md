# At Any Price (film)

At Any Price is a 2012 American drama film directed by Ramin Bahrani and written by Bahrani and Hallie Newton.  The film, starring Dennis Quaid and Zac Efron, was selected to compete for the Golden Lion at the 69th Venice International Film Festival, and later screened as an official selection at both the Telluride Film Festival and the 2012 Toronto Film Festival.  Sony Pictures Classics purchased the film and it was released in the United States on April 24, 2013.
