# 1989 World Series of Poker

The 1989 World Series of Poker (WSOP) was a series of poker tournaments held at Binion's Horseshoe.  The 1989 Main Event was won by 24-year-old Phil Hellmuth, defeating defending champion Johnny Chan, and also breaking the record for the youngest player to win the WSOP Main Event (a record previously set by Stu Ungar in 1980).  Had Chan won, he would have tied Johnny Moss's record of 3 Main Event wins.  This year also marked the first year in which Moss did not finish any WSOP tournaments inside the payout positions.
