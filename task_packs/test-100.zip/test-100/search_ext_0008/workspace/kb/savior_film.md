# Savior (film)

Savior is a 1998 war film starring Dennis Quaid, Stellan Skarsgård, Nastassja Kinski, and Nataša Ninković.  It is about an American mercenary escorting a Serbian woman and her newborn child to a United Nations safe zone during the Bosnian War.
