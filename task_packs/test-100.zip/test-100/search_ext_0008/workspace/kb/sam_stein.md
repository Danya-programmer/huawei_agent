# Sam Stein

Samuel "Sam" Stein (born January 11, 1988) is an American professional poker player from Los Angeles who lives in Henderson, Nevada.  He won his first World Series of Poker bracelet at the 2011 World Series of Poker where he made two final tables and three in the money finishes.  In both the 2010 and 2011 World Series of Poker, he finished in the money in two $10,000 Championship events, with one of them being the Pot Limit Texas hold 'em championship event each year.  Of his nine World Series of Poker (WSOP) cashes, his last five are in pot limit events.
