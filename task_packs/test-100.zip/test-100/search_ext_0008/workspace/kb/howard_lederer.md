# Howard Lederer

Howard Henry Lederer (born October 30, 1963) is an American professional poker player.  He has won two World Series of Poker bracelets and holds two World Poker Tour titles.  Lederer has also contributed to several books on poker strategy and has provided commentary for poker programming.  He is known by poker fans and players as "The Professor" and is the older brother of professional poker player Annie Duke.
