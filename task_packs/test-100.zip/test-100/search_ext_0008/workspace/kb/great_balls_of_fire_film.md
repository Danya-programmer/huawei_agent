# Great Balls of Fire! (film)

Great Balls of Fire!  is a 1989 American biographical film directed by Jim McBride and starring Dennis Quaid as rockabilly pioneer Jerry Lee Lewis.  Based on a biography by Myra Lewis and Murray M. Silver Jr., the screenplay is written by McBride and Jack Baran.  The film is produced by Adam Fields, with executive producers credited as Michael Grais, Mark Victor, and Art Levinson.
