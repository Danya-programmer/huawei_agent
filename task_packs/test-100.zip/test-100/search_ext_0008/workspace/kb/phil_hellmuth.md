# Phil Hellmuth

Phillip Jerome Hellmuth Jr. (born July 16, 1964) is an American professional poker player who has won a record fourteen World Series of Poker bracelets.  He is the winner of the Main Event of the 1989 World Series of Poker (WSOP) and the Main Event of the 2012 World Series of Poker Europe (WSOPE), and he is a 2007 inductee of the WSOP's Poker Hall of Fame.  Hellmuth is also known for his temperamental "poker brat" personality.
