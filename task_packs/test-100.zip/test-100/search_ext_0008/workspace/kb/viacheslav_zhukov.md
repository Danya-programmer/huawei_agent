# Viacheslav Zhukov

Viacheslav Zhukov (c. 1989) is a Russian professional poker player who has won two World Series of Poker bracelets. Prior to becoming a professional poker player, Zhukov was a geologist in Russia.  he has career earnings of $940,000, $838,000 of which was earned at the World Series of Poker.
