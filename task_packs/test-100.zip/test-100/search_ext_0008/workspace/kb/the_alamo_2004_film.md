# The Alamo (2004 film)

The Alamo is a 2004 American war film about the Battle of the Alamo during the Texas Revolution.  The film was directed by Texan John Lee Hancock, produced by Ron Howard, Brian Grazer, and Mark Johnson, distributed by Touchstone Pictures, and starring Dennis Quaid as Sam Houston, Billy Bob Thornton as David Crockett, and Jason Patric as Jim Bowie.
