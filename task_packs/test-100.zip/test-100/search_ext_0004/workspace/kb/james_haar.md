# James Haar

James Haar (born July 4, 1929) is an American musicologist and W.R. Kenan Jr.  Professor Emeritus of Music at the University of North Carolina at Chapel Hill.  A specialist in Renaissance music, he was the Editor-in-chief of the "Journal of the American Musicological Society" from 1966 to 1969 and served as the president of American Musicological Society from 1976 to 1978.  He was elected a member of the American Academy of Arts and Sciences in 1987.
