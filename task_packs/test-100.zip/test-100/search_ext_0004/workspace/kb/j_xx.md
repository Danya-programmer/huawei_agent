# J-XX

J-XX J-X, and XXJ are names applied by Western intelligence agencies to describe programs by the People's Republic of China to develop one or more fifth-generation fighter aircraft.  General He Weirong, Commander of the People's Liberation Air Force (PLAAF), stated that China had several such programs underway and that an undesignated fifth-generation fighter developed jointly by Chengdu Aerospace Corporation and Shenyang Aerospace Corporation would be in service by 2018.
