# Chengdu J-20

The Chengdu J-20 () is a stealth, twinjet, fifth-generation fighter aircraft developed by China's Chengdu Aerospace Corporation for the People's Liberation Army Air Force (PLAAF).  The J-20 made its maiden flight on 11 January 2011, but the plane was officially revealed on China International Aviation & Aerospace Exhibition in 2016.  In March 2017, Chinese media claimed that the aircraft has entered initial operational capability phase with limited service within Air Force.
