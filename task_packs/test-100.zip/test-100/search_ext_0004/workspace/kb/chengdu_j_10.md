# Chengdu J-10

The Chengdu J-10 ([[Simplified Chinese characters|simplified Chinese]]: 歼-10; [[Traditional Chinese characters|traditional Chinese]]: 殲-10; [[NATO reporting name]] : Firebird) is a lightweight [[multirole combat aircraft|multirole]] [[fighter aircraft]] capable of all-weather operation, configured with a [[delta wing]] and [[Canard (aeronautics)|canard]] design, with [[fly-by-wire]] flight controls, and produced by the [[People's Republic of China]]'s [[Chengdu Aircraft Industry Group|Chengdu Aircraft Corporation (CAC)]] for the [[People's Liberation Army Air Force]] (PLAAF).
