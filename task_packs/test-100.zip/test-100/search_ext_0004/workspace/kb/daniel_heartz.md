# Daniel Heartz

Daniel Heartz is an American musicologist and Professor emeritus of Music at the University of California, Berkeley.
