# Sven Hansell

Sven Hostrup Hansell (23 October 1934 – 6 March 2014) was an American musicologist and Professor Emeritus of Musicology at the University of Iowa.  He was a specialist in the music and performance practices of the 17th and 18th centuries, as well as a harpsichordist and composer.
