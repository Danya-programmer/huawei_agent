# Chengdu Aircraft Design Institute

Chengdu Aircraft Design Institute or 611 Design Institute (Chinese: 成都飞机设计研究所; pinyin: "Chéngdū fēijī shèjì yánjiūsuǒ"), or CADI, is a design institute and works with Chengdu Aerospace Corporation for military aircraft.
