# Berkeley Geochronology Center

The Berkeley Geochronology Center (BGC) is a non-profit geochronology research institute in Berkeley, California.  It was originally a research group in the laboratory of University of California Berkeley geophysicist and geochronologist Garniss Curtis, now professor emeritus.  The group is now an independent scientific research institute directed by the geologist and geochronologist Paul Renne, Professor in Residence in the Department of Earth & Planetary Science at UC Berkeley.
