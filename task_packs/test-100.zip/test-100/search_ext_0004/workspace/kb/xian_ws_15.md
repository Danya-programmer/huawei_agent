# Xian WS-15

The WS-15 (), codename Emei, is a Chinese afterburning turbofan engine designed by the Shenyang Aeroengine Research Institute and manufactured by the Xi'an Aero-Engine Corporation, used to power China's Chengdu J-20 fighter, which would be able to achieve supercruise.
