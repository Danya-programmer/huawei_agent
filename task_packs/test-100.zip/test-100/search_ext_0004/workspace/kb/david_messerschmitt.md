# David Messerschmitt

David G. Messerschmitt (born May 26, 1945) is an engineer and professor emeritus at the University of California, Berkeley in the Department of Electrical Engineering and Computer Sciences in the UC Berkeley College of Engineering.  He retired from UC Berkeley in 2005.  At present he is conducting research at Berkeley, is a visiting professor in the Software Business Laboratory at the Helsinki University of Technology, and is doing research on interstellar communications at the SETI Institute.
