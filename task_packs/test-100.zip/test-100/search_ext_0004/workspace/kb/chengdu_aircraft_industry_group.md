# Chengdu Aircraft Industry Group

The Chengdu Aircraft Industry Group or Chengdu Aerospace Corporation, a subsidiary of AVIC, is a Chinese aerospace conglomerate that designs and manufactures combat aircraft and is also a manufacturer of aircraft parts.  It was founded in 1958 (as Chengdu State Aircraft Factory No.132 Aircraft Plant) in Chengdu, Sichuan province, China to be an aircraft supplier for the Chinese military.
