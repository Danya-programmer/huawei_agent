# Guizhou WS-13

The WS-13 (Chinese: 涡扇-13), codename Taishan, is a turbofan engine designed and manufactured by Guizhou Aircraft Industry Corporation to power the Pakistan-China jointly developed JF-17 Thunder light-weight multi-role fighter, and in the near future the Shenyang J-31 fifth generation stealth fighter currently under development.
