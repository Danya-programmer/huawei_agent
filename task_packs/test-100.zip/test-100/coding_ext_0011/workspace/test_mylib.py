import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert rombus_area(10,20)==100
        assert rombus_area(10,5)==25
        assert rombus_area(4,2)==4

if __name__ == '__main__':
    unittest.main()
