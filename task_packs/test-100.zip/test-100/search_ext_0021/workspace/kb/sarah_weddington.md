# Sarah Weddington

Sarah Ragle Weddington (born February 5, 1945), is an American attorney, law professor and former member of the Texas House of Representatives best known for representing "Jane Roe" (real name Norma McCorvey) in the landmark "[REDACTED]" case before the United States Supreme Court.  In 1989, she was portrayed by Amy Madigan in the television film "Roe vs. Wade".
