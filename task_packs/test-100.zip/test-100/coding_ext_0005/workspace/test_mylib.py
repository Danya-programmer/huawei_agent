import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert find_substring(["red", "black", "white", "green", "orange"],"ack")==True
        assert find_substring(["red", "black", "white", "green", "orange"],"abc")==False
        assert find_substring(["red", "black", "white", "green", "orange"],"ange")==True

if __name__ == '__main__':
    unittest.main()
