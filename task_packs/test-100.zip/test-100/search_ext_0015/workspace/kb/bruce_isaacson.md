# Bruce Isaacson

Bruce Isaacson (born 1956) is an American poet and publisher.  He was appointed the first poet laureate of Clark County, Nevada, a community of more than two million people where Las Vegas is located, June 1, 2015 He initiated the Poets of National Stature series there, which includes readings by Juan Felipe Hererra, the sitting Poet Laureate of the United States and Beat Legend Michael McClure.  Other poets Isaacson brought previously to Las Vegas include beat feminist icon Diane di Prima, San Francisco Poet Laureate Jack Hirshman and others.
