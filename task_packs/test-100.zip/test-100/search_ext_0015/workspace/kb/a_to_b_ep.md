# A to B (EP)

A to B is a 4-track EP by American pop-rock singer-songwriter Matt Hires, released on August 17, 2010.  The Ep includes the original album version of "Honey Let Me Sing You a Song" – first found on the Tampa-based tunesmith's acclaimed 2009 debut, "Take Us to the Start", it also features 2 new songs "A To B", "Rock N' Roll Heart" and a new recording of "Honey, Let Me Sing You a Song (Alternate Version)".  The EP was released exclusively through digital service.
