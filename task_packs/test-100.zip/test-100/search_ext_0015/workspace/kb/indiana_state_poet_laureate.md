# Indiana State Poet Laureate

The Indiana State Poet Laureate is the poet laureate for the U.S. state of Indiana.  Senate Enrolled Act No. 433 created the made the position effective July 1, 2005, but Indiana had a well-established unofficial position of state poet laureate since 1929.  Laureates serve a two year term.  The selection of Indiana State Poet Laureate is made by the Indiana Arts Commission executive director and seven members chosen by the commission who represent institutions of higher education.
