# Power Balladz

Power Balladz is a live comedy performance featuring a mixture of comedy, trivia, and iconic rock n' roll songs from the 70s, 80s & 90s for which it is also named.  Created by Mike Todaro and Dan Nycklemoe with Peter Rothstein, Power Balladz began its initial theatrical run at the LAB Theatre in Minneapolis and then made its New York debut on August 5, 2010 with an opening night of August 19, 2010.  The comedy's musical blend includes songs by Journey, Queen, Scorpions, Poison, Aerosmith, Bon Jovi, Night Ranger, Styx, Heart, and more.
