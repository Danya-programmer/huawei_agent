# Ina Coolbrith

Ina Donna Coolbrith (March 10, 1841 – February 29, 1928) was an American poet, writer, librarian, and a prominent figure in the San Francisco Bay Area literary community.  Called the "Sweet Singer of California", she was the first California Poet Laureate and the first poet laureate of any American state.
