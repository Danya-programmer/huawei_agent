# List of Heart band members

Heart is an American rock band that first found success in Canada and later in the United States and worldwide.  Over the group's four-decade history it has had three primary lineups, with the constant center of the group since 1974 being sisters Ann Wilson (lead singer) and Nancy Wilson (guitarist).  While it has been referred to as a duo because of the focus on leaders Ann and Nancy Wilson, Heart is a full rock group.  In its original lineup the band had six members, then five in its second incarnation, and is again at six currently.
