# The Assignation

The Assignation, or Love in a Nunnery is a Restoration comedy written by John Dryden.  The play was first acted late in 1672, by the King's Company at their theatre at Lincoln's Inn Fields, but was not a success with its audience.
