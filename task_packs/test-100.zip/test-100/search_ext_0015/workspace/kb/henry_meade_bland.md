# Henry Meade Bland

Henry Meade Bland (April 21, 1863 – April 30, 1931) was a California educator and poet, who became California Poet Laureate in 1929 after succeeding California's first Poet Laureate, Ina Coolbrith.
