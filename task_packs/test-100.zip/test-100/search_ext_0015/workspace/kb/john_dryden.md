# John Dryden

John Dryden ( ; 19 August [O.S. 9 August] 1631 – 12 May [O.S. 1 May] 1700 ) was an English poet, literary critic, translator, and playwright who was made England's first Poet Laureate in 1668.
