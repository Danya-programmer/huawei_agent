# Ivan Mance

Ivan Mance was a Croatian football goalkeeper.  Born in Rijeka, in his first professional season he played for Varteks during the 2003-04 Prva HNL, where he had spent the first three years of his professional career.  He then moved on to lower Croatian divisions, before moving to Rijeka in 2008.  After two seasons with Rijeka, he had a short stint in Israel, with Maccabi Petah Tikva, before returning to Croatia, where he had a season with Istra 1961, before returning to Rijeka in 2012.  In late 2013, he announced retirement and assumed a management position in HNK Rijeka.
