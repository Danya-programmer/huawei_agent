# Anđelko Tešan

Anđelko Tešan (born 21 November 1949 in Sarajevo, PR Bosnia-Herzegovina, FPR Yugoslavia) is a former Bosnian professional footballer.  He started his career with FK Sarajevo in 1967, and went on to represent the club for a further ten seasons.  He also played for US teams New York Eagles and Columbia Ohio before retiring in 1981.
