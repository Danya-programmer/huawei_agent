# Samir Duro

Samir Duro (born 18 October 1977) is a Bosnian professional footballer, who plays for Čelik Zenica in the Bosnian Premier League.
