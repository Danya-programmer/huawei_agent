# Husnija Arapović

Husnija Arapović (born 7 August 1944) is a retired Bosnian professional footballer and manager.  During his career he played for NK Čelik Zenica and FK Borac Banja Luka in the Yugoslav First League, before transferring to Switzerland where he played for FC St. Gallen and FC Winterthur.  As a manager, he led FC Schaffhausen and numerous clubs in Bosnia and Herzegovina.  He was also manager of Bosnia and Herzegovina B.
