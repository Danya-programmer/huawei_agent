# Levante UD

Levante Unión Deportiva, S.A.D. (] , ] ) is a Spanish football club based in Valencia, in the namesake community.
