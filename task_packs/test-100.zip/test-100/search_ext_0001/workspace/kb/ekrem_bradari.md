# Ekrem Bradarić

Ekrem Bradarić (Serbian Cyrillic:Екрем Брадарић; born 12 July 1969 in Maglaj) is a former Bosnian professional footballer.  He played for NK Rijeka in Croatia, NK Čelik Zenica and NK Travnik in Bosnia and Adanaspor in the Turkish Super Lig.
