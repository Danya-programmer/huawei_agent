# Murat Šaran

Murat Šaran (born 24 October 1949 in Sarajevo, FPR Yugoslavia) is a former Bosnian professional footballer.  He started his career with Sarajevo lower-tier side Igman Ilidža before making his move to FK Sarajevo where he spent seven years and established himself as a first team regular.  He went on to play for Bor, Rijeka and Čelik, before making his move to Spain where he joined Levante for two seasons before retiring in 1981.
