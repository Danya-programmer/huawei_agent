# Ratko Dujković

Ratko Dujković (born 16 March 1983) is a Bosnian professional footballer who plays as goalkeeper for Čelik Zenica.
