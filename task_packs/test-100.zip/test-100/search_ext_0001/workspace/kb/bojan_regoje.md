# Bojan Regoje

Bojan Regoje (Serbian Cyrillic: ; born December 2, 1982) is a Bosnian professional footballer playing for the Premier League of Bosnia and Herzegovina club Čelik Zenica.  He previously played for FK Slavija Istočno Sarajevo from 2003-2011.
