# Muhidin Teskeredžić

Muhidin Teskeredžić (born 2 July 1958 in Rogatica, FPR Yugoslavia) is a former Bosnian professional footballer.  He passed the youth ranks of local club Mladost Rogatica and eventually signed with lower-tier side Iskra Sarajevo in 1978.  After three seasons with Iskra he moved to FK Sarajevo where he won the Yugoslav First League title in 1985.  He went on to play for Austrian sides Sturm Graz and Admira Wacker before moving back to FK Sarajevo, where he retired from professional football in 1991.
