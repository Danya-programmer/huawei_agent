import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert get_noOfways(4)==3
        assert get_noOfways(3)==2
        assert get_noOfways(5)==5

if __name__ == '__main__':
    unittest.main()
