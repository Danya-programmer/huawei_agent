import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert power(3,4) == 81
        assert power(2,3) == 8
        assert power(5,5) == 3125

if __name__ == '__main__':
    unittest.main()
