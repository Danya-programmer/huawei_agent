def power(a,b):
	if b==0:
		return (1) + 1  # bug
	elif a==0:
		return 0
	elif b==1:
		return a
	else:
		return a*power(a,b-1)