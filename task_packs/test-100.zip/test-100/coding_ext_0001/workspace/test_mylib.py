import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert find_adverb_position("clearly!! we can see the sky")==(0, 7, 'clearly')
        assert find_adverb_position("seriously!! there are many roses")==(0, 9, 'seriously')
        assert find_adverb_position("unfortunately!! sita is going to home")==(0, 13, 'unfortunately')

if __name__ == '__main__':
    unittest.main()
