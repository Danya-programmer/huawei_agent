# List of Aqua Teen Hunger Force episodes

"Aqua Teen Hunger Force" (also known by various alternative titles) is an American animated television series that aired on Cartoon Network's late night programming block, Adult Swim.  The show is about the surreal adventures and antics of three anthropomorphic fast food items: Master Shake, Frylock, and Meatwad, who live together as roommates in a neighborhood in the suburbs next door to a human named Carl Brutananadilewski.
