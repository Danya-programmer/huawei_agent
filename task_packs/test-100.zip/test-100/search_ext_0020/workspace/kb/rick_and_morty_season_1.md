# Rick and Morty (season 1)

The first season of the American animated television series, "Rick and Morty" originally aired in the United States on Cartoon Network's late night programming block, Adult Swim.  It premiered on December 2, 2013 with "Pilot" and ended on April 14, 2014 with "Ricksy Business", with a total of eleven episodes.  The first season received critical acclaim.
