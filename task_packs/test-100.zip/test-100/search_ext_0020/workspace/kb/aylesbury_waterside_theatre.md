# Aylesbury Waterside Theatre

Aylesbury Waterside Theatre is a £47 million theatre in Aylesbury, England, United Kingdom presenting a range of West End and touring musicals and plays, along with performances of opera and ballet and a Christmas pantomime.
