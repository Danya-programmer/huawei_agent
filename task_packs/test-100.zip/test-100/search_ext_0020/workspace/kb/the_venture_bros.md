# The Venture Bros.

The Venture Bros. is an American animated television series that was created by Christopher McCulloch (also known as "Jackson Publick") and premiered on Cartoon Network's late night programming block Adult Swim with a pilot episode on February 16, 2003 and its first season beginning on August 7, 2004.  It is considered to be an action/adventure series with comedy-drama elements.  The show has been renewed for a seventh and eighth season to consist of ten episodes each.
