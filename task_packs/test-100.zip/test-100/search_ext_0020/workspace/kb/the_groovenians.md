# The Groovenians

The Groovenians is an American computer-animated pilot created by Kenny Scharf and produced by Cartoon Network Studios.  It was aired on Cartoon Network's late night programming block Adult Swim on November 10, 2002, but was also re-aired on Cartoon Network itself during the block "Cartoon Cartoon Fridays" on February 21, 2003.  Its theme song was performed by The B-52's, well known for performing "Rock Lobster" plus the seasons 2-4 theme for "Rocko's Modern Life".  The pilot was panned by critics and audiences, causing the episode to be dropped.
