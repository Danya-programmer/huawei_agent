# Revolt of the Beavers

Revolt of the Beavers was a children's play put on by the Federal Theater Project by Oscar Saul and Louis Lantz.  One critic described the play as "Marxism a la Mother Goose".  The show ran at the Adelphi Theatre in New York City from May 20, 1937, to June 19 of that year.  Jules Dassin and John Randolph were among the play's cast.
