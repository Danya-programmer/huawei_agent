import unittest
import otherlib as mylib
from otherlib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert first_repeated_word("ab ca bc ab") == "ab"
        assert first_repeated_word("ab ca bc") == 'None'
        assert first_repeated_word("ab ca bc ca ab bc") == "ca"

if __name__ == '__main__':
    unittest.main()
