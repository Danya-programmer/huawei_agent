import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert lcs_of_three('AGGT12', '12TXAYB', '12XBA') == 2
        assert lcs_of_three('Reels', 'Reelsfor', 'ReelsforReels') == 5
        assert lcs_of_three('abcd1e2', 'bc12ea', 'bd1ea') == 3

if __name__ == '__main__':
    unittest.main()
