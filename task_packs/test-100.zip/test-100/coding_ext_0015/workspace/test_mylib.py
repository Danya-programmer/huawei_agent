import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert chinese_zodiac(1997)==('Ox')
        assert chinese_zodiac(1998)==('Tiger')
        assert chinese_zodiac(1994)==('Dog')

if __name__ == '__main__':
    unittest.main()
