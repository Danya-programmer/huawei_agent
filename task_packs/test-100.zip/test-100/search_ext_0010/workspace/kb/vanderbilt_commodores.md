# Vanderbilt Commodores

The Vanderbilt Commodores are the NCAA athletic teams of Vanderbilt University, located in Nashville, Tennessee.  The university fields 16 varsity teams (6 men's teams and 10 women's teams), 14 of which compete in the Southeastern Conference.  Vanderbilt's women's lacrosse team plays in the Big East Conference, while the bowling team plays in the Southland Bowling League.  The University of Tennessee Volunteers are Vanderbilt's primary athletic rival, and the only other SEC team in the state of Tennessee.
