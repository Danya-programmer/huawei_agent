# TCU Horned Frogs

The TCU Horned Frogs are the athletic teams that represent Texas Christian University.  The 18 varsity teams participate in NCAA Division I and in the Football Bowl Subdivision (FBS) for football competing in the Big 12 Conference.  On October 10, 2011, TCU announced that it had accepted an invitation to join the Big 12 Conference.
