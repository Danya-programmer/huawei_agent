# Dragan Šakota

Dragan Šakota (Serbian Cyrillic: Драган Шакота, Greek: Ντράγκαν Σάκοτα; born June 16, 1952 in Belgrade) is a Serbian-Greek professional basketball coach.  His son, Dušan Šakota, is also a professional basketball player, while his other son, Miloš Šakota, is a retired professional basketball player, and a current professional basketball coach.
