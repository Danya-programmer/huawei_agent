# Gary Owen (comedian)

Gary Owen (born July 26, 1974) is an American actor and stand-up comedian.  After being named "Funniest Serviceman In America," his big break came in 1997 on Black Entertainment Television's stand-up showcase "Comic View".  Owen followed this debut with featured roles in the films "Daddy Day Care", "Little Man", and "College".  He has cultivated an African-American following after headlining on cable channel BET and performing at targeted events, such as Shaquille O'Neal's All-Star Comedy Jam Tour.  He has an upcoming TV show on BET called "The Gary Owen Show".
