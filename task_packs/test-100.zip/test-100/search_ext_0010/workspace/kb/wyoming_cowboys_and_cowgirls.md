# Wyoming Cowboys and Cowgirls

The Wyoming Cowboys and Cowgirls are the athletic teams that represent the University of Wyoming.  Wyoming is a member of the Mountain West Conference (MW) and competes in NCAA Division I, fielding 17 NCAA-sanctioned sports.  Two Wyoming teams compete in other conferences in sports that the MW does not sponsor.  The men's swimming and diving team competes in the Western Athletic Conference, and the wrestling team competes in the Big 12 Conference.
