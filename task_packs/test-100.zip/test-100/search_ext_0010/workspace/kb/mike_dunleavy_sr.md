# Mike Dunleavy Sr.

Michael Joseph Dunleavy Sr. (born March 21, 1954) is an American retired professional basketball player, head coach, and former general manager of the National Basketball Association's Los Angeles Clippers.  He is currently the head coach of the Tulane University men's basketball team.  Dunleavy is the father of professional basketball player Mike Dunleavy Jr., who now plays for the Atlanta Hawks of the National Basketball Association (NBA).
