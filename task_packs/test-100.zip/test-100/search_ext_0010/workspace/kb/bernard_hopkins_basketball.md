# Bernard Hopkins (basketball)

Bernard Anthony Hopkins White (born January 13, 1973) is an American-Spanish retired professional basketball player.  Hopkins is a 6'6", 235-pound power forward.  He played college ball at Hagerstown Community College for two seasons before transferring to Virginia Commonwealth University (VCU) for his final two.  As a senior in 1995–96, Hopkins was named the 1996 CAA Men's Basketball Tournament MVP as well as the Colonial Athletic Association Men's Basketball Player of the Year.
