# Shaquille O'Neal

Shaquille Rashaun O'Neal ( ; born March 6, 1972), nicknamed "Shaq" ( ), is an American retired professional basketball player and rapper, currently serving as a sports analyst on the television program "Inside the NBA".  Listed at 7 ft tall and weighing 325 lb , he was one of the heaviest players ever to play in the NBA, where he played for six teams throughout his 19-year career.
