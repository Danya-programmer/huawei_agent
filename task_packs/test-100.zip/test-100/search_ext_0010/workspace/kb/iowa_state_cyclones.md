# Iowa State Cyclones

The Iowa State Cyclones are the athletic teams that represent Iowa State University.  The university is a member of the Big 12 Conference and competes in NCAA Division I, fielding 16 varsity teams (6 men's and 10 women's teams) in 12 sports.
