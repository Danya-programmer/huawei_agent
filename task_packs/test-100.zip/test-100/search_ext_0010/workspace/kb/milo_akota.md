# Miloš Šakota

Miloš Šakota (, Greek: Μίλος Σάκοτα , born June 11, 1984) is a retired Greek professional basketball player and basketball coach of Serbian descent.  He is the son of former professional basketball player and coach, Dragan Šakota, and the brother of professional basketball player Dušan Šakota.  He is 6'8¾" (2.05 m) tall, and during his playing career, he played at both the small forward and power forward positions.
