import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert longest_increasing_subsequence([10, 22, 9, 33, 21, 50, 41, 60]) == 5
        assert longest_increasing_subsequence([3, 10, 2, 1, 20]) == 3
        assert longest_increasing_subsequence([50, 3, 10, 7, 40, 80]) == 4 

if __name__ == '__main__':
    unittest.main()
