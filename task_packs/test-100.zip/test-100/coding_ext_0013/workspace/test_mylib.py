import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert toggle_middle_bits(9) == 15
        assert toggle_middle_bits(10) == 12
        assert toggle_middle_bits(11) == 13

if __name__ == '__main__':
    unittest.main()
