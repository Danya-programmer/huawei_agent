# Matamoros, Tamaulipas

Matamoros, officially known as Heroica Matamoros, is a city in the northeastern Mexican state of Tamaulipas.
