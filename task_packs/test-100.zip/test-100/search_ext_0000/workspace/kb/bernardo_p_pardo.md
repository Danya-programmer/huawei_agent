# Bernardo P. Pardo

Bernardo Pardo (February 11, 1932) is a former Philippine Supreme court Associate justice and a former Comelec Chairman.  He was appointed by former Philippine President Joseph Estrada.  He was born in Manila, to San Isidro, Nueva Ecija natives, Dr. and Mrs. Leopoldo G. Pardo, and is married to Zenaida C. De Dios, with whom he has 4 children: Lourdes, Bernardita, Mercedes Patricia, and Victor.
