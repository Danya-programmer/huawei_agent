# Carla Estrada

Carla Estrada (born Carla Patricia Estrada Guitrón on March 11, 1956 in Mexico City, D.F., Mexico) is a Mexican producer, one of the foremost telenovela producers of Latin America.
