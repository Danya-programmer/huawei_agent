# Diana Estrada

Diana Karina Estrada Santana (born April 16, 1986 in Mexico City) is a female beach volleyball player from Mexico, who won the gold medal in the women's beach team competition at the NORCECA Beach Volleyball Circuit 2008 in Guadalajara, Jalisco, partnering Martha Revuelta.  Later, in September 2008, she competed with her sister Paola Estrada, at the "Internacional de Puerto Vallarta Beach Volleyball Tournament" in Puerto Vallarta, Jalisco, winning the Bronze medal.
