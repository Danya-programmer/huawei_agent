# Manuel Barillas

Manuel Lisandro Barillas Bercián (Quetzaltenango, 17 January 1845–Mexico City, 15 March 1907) was a Guatemalan general and acting president of Guatemala from 6 April 1885 to 15 March 1886 and President from 16 March 1886 to 15 March 1892.  He was born in Quetzaltenango, and assassinated (at the behest of his enemy Manuel Estrada Cabrera, President of Guatemala at the time) in Mexico City in 1907.
