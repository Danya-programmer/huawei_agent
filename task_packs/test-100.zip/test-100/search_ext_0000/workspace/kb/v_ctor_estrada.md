# Víctor Estrada

Victor Manuel Estrada Garibay (born October 28, 1971 in Matamoros, Tamaulipas) is a Mexican taekwondo practitioner and Olympic medalist.  He competed at the 2000 Summer Olympics in Sydney where he received a bronze medal in the 80 kg division.  He also competed at the 2004 Athens Olympics, finishing in equal fifth position.
