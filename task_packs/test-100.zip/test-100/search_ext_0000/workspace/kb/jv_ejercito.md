# JV Ejercito

Joseph Victor Gomez Ejercito (born December 26, 1969 in Manila), commonly known as JV Ejercito or JV Ejercito Estrada, is the son of Philippine President Joseph Estrada.
