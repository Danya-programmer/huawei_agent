# The Flower of Hawaii (1953 film)

The Flower of Hawaii (German:Die Blume von Hawaii) is a 1953 West German musical film directed by Géza von Cziffra and starring Maria Litto, William Stelling and Rudolf Platte.  It uses the music of the operetta "The Flower of Hawaii" by Paul Abraham, but the story was rewritten.  Unlike the 1933 film "The Flower of Hawaii", this film is not based on the life of the last Queen of Hawaii Liliuokalani.
