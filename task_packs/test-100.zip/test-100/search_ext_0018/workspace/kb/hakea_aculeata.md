# Hakea aculeata

Hakea aculeata, commonly known as the Column Hakea, is a vulnerable species of "Hakea" found in the Brookton, Cunderdin, Merredin, Tammin and Quairading areas in the Wheatbelt region of Western Australia.
