# Carposina autologa

Carposina autologa, the hakea seed-moth, is a moth in the Carposinidae family.  It is found in Australia, where it has been recorded from Western Australia.  It has been released in South Africa for the biological control "Hakea sericea".
