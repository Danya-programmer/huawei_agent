# Géza von Cziffra

Géza von Cziffra (] ; 19 December 1900 – 28 April 1989) was a Hungarian and Austrian film director and screenwriter.
