# Henry Selick

Henry Selick (born November 30, 1952) is an American stop motion director, producer and writer who is best known for directing "The Nightmare Before Christmas", "James and the Giant Peach" and "Coraline".  He studied at the Program in Experimental Animation at California Institute of the Arts, under the guidance of Jules Engel.
