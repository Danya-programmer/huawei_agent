# So ein Millionär hat's schwer

So ein Millionär hat's schwer is a 1958 Austrian film directed by Géza von Cziffra.
