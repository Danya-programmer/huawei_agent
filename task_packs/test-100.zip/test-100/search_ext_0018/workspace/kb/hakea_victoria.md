# Hakea victoria

Hakea victoria, with common names Royal Hakea and Lantern Hakea, is a shrub which is native to Western Australia and noted for its ornamental foliage.  The Noongar name for the plant is Tallyongut.
