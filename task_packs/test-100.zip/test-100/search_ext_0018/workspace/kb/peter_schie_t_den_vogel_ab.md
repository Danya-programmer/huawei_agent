# Peter schießt den Vogel ab

Peter schießt den Vogel ab is a 1959 West German film directed by Géza von Cziffra.
