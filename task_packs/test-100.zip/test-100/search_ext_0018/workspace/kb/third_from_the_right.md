# Third from the Right

Third from the Right (German: Die Dritte von rechts) is a 1950 West German musical crime film directed by Géza von Cziffra and starring Vera Molnar, Robert Lindner and Peter van Eyck.  It was made by the Hamburg-based studio Real Film.
