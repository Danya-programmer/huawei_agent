# Hakea laurina

Hakea laurina is a plant of Southwest Australia that is widely cultivated and admired.  The species is often referred to as Kodjet, Pincushion Hakea, and Emu Bush.  The specific epithet, derived from the Latin "laurus", is given for the resemblance to the leaves of laurel.  The Noongar name for the plant is Kodjet or Kojet.
