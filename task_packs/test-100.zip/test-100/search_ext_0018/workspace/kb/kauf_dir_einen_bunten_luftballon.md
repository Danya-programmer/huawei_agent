# Kauf dir einen bunten Luftballon

Kauf dir einen bunten Luftballon is a 1961 West German / Austrian film directed by Géza von Cziffra.
