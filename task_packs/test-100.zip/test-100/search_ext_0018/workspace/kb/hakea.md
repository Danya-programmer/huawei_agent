# Hakea

Hakea (pincushion tree) is a genus of 149 species of shrubs and small trees in the Proteaceae, native to Australia.  They are found throughout the country, with the highest species diversity being found in the south west of Western Australia.
