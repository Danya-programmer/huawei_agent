# Kriminaltango (film)

Kriminaltango is a 1960 Austrian film directed by Géza von Cziffra.  It was a remake of the 1949 West German film "Dangerous Guests" which had also been directed by von Cziffra.
