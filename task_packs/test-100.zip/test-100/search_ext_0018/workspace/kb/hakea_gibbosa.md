# Hakea gibbosa

Hakea gibbosa, commonly known as hairy hakea or rock hakea, is a shrub of the family Proteaceae native to southeastern Australia.  It has become an environmental weed in South Africa and New Zealand, where it had been introduced for use as a hedge plant.
