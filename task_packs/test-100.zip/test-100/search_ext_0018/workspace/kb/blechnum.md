# Blechnum

Blechnum (hard fern) is a genus of between 150–220 species of ferns with a cosmopolitan distribution, in the family Blechnaceae in the eupolypods II clade of the order Polypodiales.  By far the greatest species diversity is in tropical regions of the Southern Hemisphere, with only a few species reaching cool temperate latitudes in the Southern Hemisphere (notably "B. penna-marina", south to Cape Horn, Chile, the southernmost fern in the world) and Northern Hemisphere (notably "B. spicant", north to Iceland and northern Norway).
