# Hakea preissii

Hakea preissii, commonly known as the Needle tree, Needle bush and Christmas hakea, is a shrub or tree of the genus "Hakea" native to an area in the Pilbara, Wheatbelt, Mid West and Goldfields-Esperance regions of Western Australia.  The Noongar name for the plant is Tanjinn.
