# Hakea microcarpa

Hakea microcarpa , commonly known as small-fruit hakea is a flowering plant in the family Proteaceae and is endemic to eastern Australia.  It is a spreading shrub, often growing in woodlands, heathlands and near swamps in montane areas of eastern Australia.
