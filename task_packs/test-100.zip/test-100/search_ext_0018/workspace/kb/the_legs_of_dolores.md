# The Legs of Dolores

The Legs of Dolores (German: Die Beine von Dolores) is a 1957 West German musical comedy film directed by Géza von Cziffra and starring Germaine Damar, Claus Biederstaedt and Ruth Stephan.
