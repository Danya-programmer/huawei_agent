# Hakea leucoptera

Hakea leucoptera is a plant of the dry regions of Australia.  The species is often referred to as silver needlewood, needle hakea, pin bush, and water tree.  It has several indigenous names; Booldoobah, Uri, Kuluva, and Kuloa.  The specific epithet, derived from the Latin "Leucoptera" (Gk): "leuco" means "white"; and "ptera" means "winged", referring to the characteristic white-winged seeds of this species.
