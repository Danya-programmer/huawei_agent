import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert concatenate_nested((3, 4), (5, 6)) == (3, 4, 5, 6)
        assert concatenate_nested((1, 2), (3, 4)) == (1, 2, 3, 4)
        assert concatenate_nested((4, 5), (6, 8)) == (4, 5, 6, 8)

if __name__ == '__main__':
    unittest.main()
