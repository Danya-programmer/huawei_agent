sales data was not shipped
