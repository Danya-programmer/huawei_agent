import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert largest_triangle(4,2)==10.392304845413264
        assert largest_triangle(5,7)==4.639421805988064
        assert largest_triangle(9,1)==105.2220865598093

if __name__ == '__main__':
    unittest.main()
