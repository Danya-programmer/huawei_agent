# Lucas Matthysse

Lucas Martin Matthysse (born September 27, 1982) is an Argentine professional boxer.  He held the WBC interim super lightweight title from 2012 to 2013, and has challenged twice for a world title in 2013 and 2015.  Matthysse is known for his aggressive pressure fighting style and formidable punching power.  His older brother is former professional boxer Walter Matthysse.
