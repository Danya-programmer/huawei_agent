# Chumlee

Austin Lee Russell (born September 8, 1982), better known by his stage name of Chumlee, is an American actor, businessman and reality television personality, known as a cast member on the History Channel television show "Pawn Stars", which depicts the daily business at the Gold and Silver Pawn Shop in Las Vegas where Russell works as an employee.  Chumlee came to work at the pawn shop five years before filming of the first season, having been a childhood friend of Corey Harrison, whose father, Rick Harrison, and grandfather, Richard Benjamin Harrison, opened the shop in 1989.
