# Rick Harrison

Richard Kevin "Rick the Spotter" Harrison (born March 22, 1965) is an American, Las Vegas-based businessman and reality television personality, best known as the co-owner of the World Famous Gold & Silver Pawn Shop, as featured on the History series "Pawn Stars".  He co-owns the pawn shop with his father, Richard Benjamin Harrison, which they opened in 1989.  Harrison dropped out of high school to pursue his "$2,000-a-week business of selling fake Gucci bags".
