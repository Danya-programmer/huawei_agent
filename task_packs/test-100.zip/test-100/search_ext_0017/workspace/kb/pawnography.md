# Pawnography

Pawnography is an American game show broadcast by History.  Hosted by comedian Christopher Titus and featuring "Pawn Stars" personalities Rick Harrison, Corey Harrison and Austin "Chumlee" Russell as panelists, the series features contestants answering questions for a chance to win cash and items for sale from the Gold and Silver Pawn Shop (where "Pawn Stars" is taped).  The show premiered July 10, 2014, at 10 p.m. ET, following "Pawn Stars".
