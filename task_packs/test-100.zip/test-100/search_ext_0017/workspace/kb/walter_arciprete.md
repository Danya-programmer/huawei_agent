# Walter Arciprete

Walter Dario Arciprete (born May 25, 1979) is an Argentine former swimmer, who specialized in breaststroke and in individual medley events.  He represented Argentina at the 2000 Summer Olympics, and achieved numerous Argentine titles and records from the national championships, including his 50 m breaststroke standard (27.81) that stood for more than a decade.
