# Pawn Shop Chronicles

Pawn Shop Chronicles, also known as Hustlers, is a 2013 crime comedy film directed by Wayne Kramer and written by Adam Minarovich.  The film stars an ensemble cast, led by Paul Walker, Matt Dillon, Brendan Fraser, Vincent D'Onofrio, Norman Reedus, and Chi McBride.  Centering on the events in and around a pawn shop, "Pawn Shop Chronicles" tells three overlapping stories involving items found within said pawn shop.  This was the final film featuring Walker to be released in his lifetime.
