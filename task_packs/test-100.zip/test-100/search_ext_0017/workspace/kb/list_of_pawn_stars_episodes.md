# List of Pawn Stars episodes

"Pawn Stars" is an American reality television series that premiered on History on July 19, 2009.  The series is filmed in Las Vegas, Nevada, where it chronicles the activities at the World Famous Gold & Silver Pawn Shop, a 24-hour family business operated by patriarch Richard "Old Man" Harrison, his son Rick Harrison, Rick's son Corey "Big Hoss" Harrison, and Corey's childhood friend, Austin "Chumlee" Russell.
