# Liam Smith (boxer)

Liam Smith (born 27 July 1988) is a British professional boxer.  He held the WBO light-middleweight title from 2015 to 2016, having previously held the Commonwealth light-middleweight title from 2012 to 2013, and the British light-middleweight title from 2013 to 2015.  Liam is the younger brother of Paul Smith and Stephen Smith, and the older brother of Callum Smith; all of whom are also professional boxers.
