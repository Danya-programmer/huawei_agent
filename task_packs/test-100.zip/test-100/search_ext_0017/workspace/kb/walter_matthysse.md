# Walter Matthysse

Walter Dario Matthysse (born August 29, 1978) is an Argentine former professional boxer who competed from 2002 to 2009, and challenged once for the IBF welterweight title in 2007.  He is the elder brother of professional boxer Lucas Matthysse.
