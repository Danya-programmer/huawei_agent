# Lucas Martin

Lucas Martin (born February 22, 1968) is a retired American soccer forward.  Martin played three seasons in the Western Soccer Alliance and one in the American Professional Soccer League.  He also earned two caps with the U.S. national team.  He is now the co-owner and head chef of K&L Bistro in Sebastopol, California.
