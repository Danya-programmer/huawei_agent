# Corey Harrison

Richard Corey "Big Hoss" Harrison (born April 27, 1983) is an American businessman and reality television personality, known as a cast member of the History TV series "Pawn Stars", which documents his work at the World Famous Gold & Silver Pawn Shop in Las Vegas, which he co-owns with his father, Rick Harrison, and grandfather, Richard Benjamin Harrison.
