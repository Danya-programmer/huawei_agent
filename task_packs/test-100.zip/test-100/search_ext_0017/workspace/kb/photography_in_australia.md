# Photography in Australia

Photography in Australia started in the 1840s.  The first photograph taken in Australia, a view of Bridge Street (now lost) is believed to have been taken by a visiting naval captain, Captain Augustin Lucas (1804-1854) in 1841.  The existence of the photograph was indicated in a note published in the "Australasian Chronicle" on 13 April of that year.  Lucas arrived in Sydney aboard the "Justine", captained by his younger brother Francois Lucas.
