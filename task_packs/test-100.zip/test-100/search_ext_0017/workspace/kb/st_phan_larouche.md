# Stéphan Larouche

Stéphan Larouche is a Canadian boxing trainer based in Montreal, Quebec.  Larouche has trained many of the best-known boxers of recent years in Quebec and was one of the two coaches of the Canadian team at the 2004 Summer Olympics.  He was named as trainer of the year by FightNews Canada in 2005 and 2008.  The list of boxers that worked with Larouche includes Éric Lucas, Leonard Dorin and Lucian Bute.  He has had a long association with the promotion company Interbox and is currently its director of operations.
