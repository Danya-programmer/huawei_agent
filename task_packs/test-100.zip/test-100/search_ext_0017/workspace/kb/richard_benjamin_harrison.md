# Richard Benjamin Harrison

Richard Benjamin Harrison Jr., (also known by the nicknames The Old Man and The Appraiser) (born March 4, 1941), is a Las Vegas businessman and reality television personality, best known as the co-owner of the World Famous Gold & Silver Pawn Shop, as featured on the History channel series "Pawn Stars".  Harrison was the co-owner of a pawn shop with his son Rick Harrison until he suffered a stroke, causing him to retire.They opened the store together in 1989.
