# Otto F. Walter

Otto F. Walter (5 June 1928 born as "Otto Friedrich Walter" – 24 September 1994) was a Swiss publisher (Walter Verlag), author and novelist, which is well known in the German language countries.  Otto Friedrich Walter was the younger brother of Silja Walter, a Benedictine nun in the Fahr Abbey and also a popular writer.
