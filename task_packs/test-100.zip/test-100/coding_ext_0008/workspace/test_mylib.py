import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert multiply_int(10,20)==200
        assert multiply_int(5,10)==50
        assert multiply_int(4,8)==32

if __name__ == '__main__':
    unittest.main()
