import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert pair_OR_Sum([5,9,7,6],4) == 47
        assert pair_OR_Sum([7,3,5],3) == 12
        assert pair_OR_Sum([7,3],2) == 4

if __name__ == '__main__':
    unittest.main()
