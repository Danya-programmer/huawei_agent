# Statue of the Earl Mountbatten, London

The statue of the Earl Mountbatten is an outdoor bronze statue of Admiral of the Fleet Louis Mountbatten, 1st Earl Mountbatten of Burma, located on Mountbatten Green, off Horse Guards Road, Whitehall, London, England.  The sculptor was Franta Belsky and the work was unveiled in 1983.
