# Mountbatten Medal

The IET Mountbatten Medal is awarded annually for an outstanding contribution, or contributions over a period, to the promotion of electronics or information technology and their application.  The Medal was established by the National Electronics Council in 1992 and named after Louis Mountbatten, The Earl Mountbatten of Burma, Admiral of the Fleet and Governor-General of India.  Since 2011, the medal has been awarded as one of the IET Achievement Medals.
