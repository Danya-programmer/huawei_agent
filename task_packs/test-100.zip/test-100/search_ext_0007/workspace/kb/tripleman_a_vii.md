# Triplemanía VII

Triplemanía VII was the seventh "Triplemanía" wrestling show promoted by AAA.  The show took place on June 11, 1999, in Madero, Mexico.  The Main event featured a Six-man "Lucha Libre rules" tag team match between the teams of Perro Aguayo, Octagón and El Cobarde II and El Texano, Perro Aguayo Jr. and Sangre Chicana.  In the semi-main event Heavy Metal and El Felino defended the hair of their father, referee Pepe "Tropi" Casas while Kick Boxer and Thai Boxer defended the hair of referee El Tirantes.  As a result, El Tirantes had his hair shaved off after the match.
