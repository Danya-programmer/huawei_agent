# Betting controversies in cricket

Cricket has had a number of controversies relating to players being involved with the betting aspects of the game.  In particular, numerous players have been approached by bookmakers and bribed to throw matches, aspects of matches (e.g. the toss) or provide other information.
