# Mountbatten Institute

The Mountbatten Institute (formerly known as the Mountbatten Internship Programme) is an organization based in New York and London dedicated to fostering work experience and cultural exchange by placing international graduate students abroad to earn postgraduate certificates and degrees.  Named in honour of Louis Mountbatten, 1st Earl Mountbatten of Burma and benefacted by his eldest daughter Patricia, 2nd Countess Mountbatten, the organization was founded in 1984.
