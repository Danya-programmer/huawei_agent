# Britain–Burma Society

The Britain Burma Society (BBS) is a society founded in 1957 under the distinguished patronage of Earl Mountbatten of Burma, Sir Hubert Rance (formerly Governor of Burma), Miss Dorothy Woodman, the Rt.  Hon. Malcolm MacDonald, the Rt.  Hon. Arthur Bottomley and others.
