# Guerra de Titanes (1998)

"Guerra de Titanes" (1998) ("War of the Titans") was the second "Guerra de Titanes" professional wrestling show promoted by AAA.  The show took place on December 13, 1998 in Chihuahua, Chihuahua, Mexico.  The Main event featured a Steel Cage Match that highlighted two storyline feuds between Octagón and his "Evil twin" Pentagón and the feud between Heavy Metal and Kick Boxer as Octagón and Heavy Metal teamed together to take on Pentagón and Kick Boxer.
