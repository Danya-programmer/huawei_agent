# Countess Mountbatten of Burma

Countess Mountbatten of Burma is a peerage in the United Kingdom encompassing certain of the wives and daughters of the Earl Mountbatten of Burma.  The family seat for the position is at Newhouse Manor, near Ashford, Kent.
