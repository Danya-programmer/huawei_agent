# Sir

Sir is an honorific address used in a number of situations in many anglophone cultures.  The term can be used as a formal prefix, especially in the Commonwealth, for males who have been given certain honours or titles (such as knights and baronets), where usage is strictly governed by law and custom.
