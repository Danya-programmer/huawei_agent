# Marjorie Pratt, Countess of Brecknock

Marjorie Minna Jenkins Pratt, Countess of Brecknock DBE, JP (died 24 August 1989), was a British peeress.  She was the daughter of Colonel Atherton Edward Jenkins and his wife, Anna Isabella (née Schoenbrunn), the niece of Sir Ernest Cassel.  She was a cousin (and life-long close friend) of Edwina Ashley, who married Lord Louis Mountbatten, 1st Earl Mountbatten of Burma.
