# Earl Mountbatten of Burma

Earl Mountbatten of Burma is a title in the Peerage of the United Kingdom.  It was created in 1947 for Rear Admiral Louis Mountbatten, 1st Viscount Mountbatten of Burma, the last Viceroy of India.  The letters patent creating the title specified the following special remainder:
