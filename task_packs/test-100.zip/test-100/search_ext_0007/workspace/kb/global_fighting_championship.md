# Global Fighting Championship

Global Fighting Championship (also known as GFC) was a UAE-based kickboxing and mixed martial arts (MMA) event.  Fighters from around world on the roster include Badr Hari, Peter Aerts, Peter Graham, Dewey Cooper, Zabit Samedov.  It was considered as one of the biggest kickboxing and MMA promotion in Middle East. <ref name="Emirates 24/7"> </ref>
