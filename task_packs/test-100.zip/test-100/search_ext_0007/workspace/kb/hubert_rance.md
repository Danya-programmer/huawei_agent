# Hubert Rance

Major General Sir Hubert Elvin Rance (1898–1974) was the last Governor of British Burma between 1946 and 1948, during the transition from Japanese to British colonial administration.  Later he became Governor of Trinidad and Tobago.
