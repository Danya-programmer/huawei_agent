# Protection racket

A protection racket is a scheme whereby a group provides protection to businesses or other groups through violence outside the sanction of the law.  Through the credible threat of violence, the racketeers deter people from swindling, robbing, injuring, sabotaging or otherwise harming their clients.  Protection rackets tend to appear in markets where the police and judiciary cannot be counted on to provide legal protection, either because of incompetence (as in weak or failed states) or illegality (black markets).
