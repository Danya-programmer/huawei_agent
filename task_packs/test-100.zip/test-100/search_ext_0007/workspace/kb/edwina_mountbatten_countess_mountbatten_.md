# Edwina Mountbatten, Countess Mountbatten of Burma

Edwina Cynthia Annette Mountbatten, Countess Mountbatten of Burma, ("née" Ashley; 28 November 1901 – 21 February 1960) was an English heiress, socialite, relief worker and the last Vicereine of India as wife of Louis Mountbatten, 1st Earl Mountbatten of Burma.
