# Badr Hari

Badr Hari (Arabic: بدر هاري‎ ‎ ; born 8 December 1984) is a Moroccan-Dutch super heavyweight kickboxer from Amsterdam, fighting out of Mike's Gym in Oostzaan.  He is a former K-1 Heavyweight champion (2007—2008), It's Showtime Heavyweight world champion (2009-2010) and "K-1 World Grand Prix 2009" finalist.  Hari has been a prominent figure in the world of kickboxing and was once considered the best kickboxer in the world, however he has been involved in a number of controversies relating to his "unsportsmanlike conducts" in the sport and crimes of violence outside of the ring.
