# List of shipwrecks in the Bristol Channel

A number of ships have run aground or sunk in the Bristol Channel, a stretch of water between southern Wales and Somerset.  Cardiff, Barry and Penarth were once the largest coal exporters in the world and the channel received significant traffic at the beginning of the twentieth century during exportation.
