# Albus Dumbledore

Professor Albus Percival Wulfric Brian Dumbledore is a fictional character in J. K. Rowling's "Harry Potter" series.  For most of the series, he is the headmaster of the wizarding school Hogwarts.  As part of his backstory, it is revealed that he is the founder and leader of the Order of the Phoenix, an organisation dedicated to fighting Lord Voldemort.
