# Mohammad Tauqir

Mohammad Tauqir Khan (Arabic: توقير محمد‎ ‎ ; born January 14, 1972 in Dubai) is a United Arab Emirates cricketer.  He is a UAE national.  He is a lower order batsman and off-spin bowler, he played his first game for UAE in the final of 1996 ACC Trophy (batting at 11 and not bowling).  He has been part of the UAE team in the last three ICC Trophys and last six ACC Trophys.  His best bowling performance came against Japan with 6–10 off 10 overs in the 2000 ACC Trophy.
