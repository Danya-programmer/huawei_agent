# SS City of Adelaide (1863)

The "City of Adelaide" was a passenger steam ship launched in 1863 in Glasgow, Scotland.  The vessel was later converted to a Barque for use as a cargo transport.  In 1912 the vessel was gutted by fire, and in 1916 the burnt hulk was run aground in Cockle Bay, Magnetic Island, Australia.  During the Second World War four people were killed in a training accident when a RAAF aircraft struck the masts of the vessel.
