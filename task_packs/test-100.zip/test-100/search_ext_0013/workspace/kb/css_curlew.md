# CSS Curlew

CSS "Curlew" was an iron-hull North Carolina Sounds paddlewheel steamboat that was taken into the Confederate Navy in 1861.  It was run aground at Fort Forrest ( ) and burned in the battle for Roanoke Island on February 8, 1862.  Its wreck was discovered in 1988 and archaeologically investigated in 1994.
