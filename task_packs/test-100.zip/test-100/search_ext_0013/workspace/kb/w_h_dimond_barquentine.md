# W. H. Dimond (barquentine)

W. H. Dimond was a three-masted barquentine of 390 tons, built by Matthew Turner, of Benicia, California, for J. D. Spreckles for the Island trade.  Later transferred to the Oceanic Steamship Co., she was sold out of the trade in 1905, and was converted to a schooner by the Alaska Codfish Co.  She was wrecked 17 February 1914, having run aground on Bird Island, Alaska, carrying general cargo from San Francisco to Unga Island.  Her lines, sailplan, and a rendering are shown in Chapelle's "The History Of American Sailing Ships".
