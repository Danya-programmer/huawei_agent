# Rescue Rock

Rescue Rock ( ) is a submerged rock marked by breakers, 0.6 nautical miles (1.1 km) northeast of Skua Island in the entrance to the Bay of Isles, South Georgia.  Charted in 1930 by DI survey personnel.  So named because a whale catcher passing near this rock sighted a flag on Skua Island, eventually leading to the rescue of the survey party at Camp Bay where their vessel had run aground.
