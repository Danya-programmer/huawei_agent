# Sardinia

Sardinia ( ; Italian: "Sardegna" ] , Sardinian: "Sardìgna/Sardìnnia" ] /] , Sassarese: "Sardhigna", Gallurese: "Saldigna", Catalan: "Sardenya", Tabarchino: "Sardegna") is the second largest island in the Mediterranean Sea (after Sicily and before Cyprus) and an autonomous region of Italy.  It is located in the Western Mediterranean, to the immediate south of the French island of Corsica.
