# Dennis McKinney

Dennis McKinney (born July 24, 1960) is a former Kansas State Treasurer.  He was a member of the Kansas House of Representatives where he represented the 116th House District for ten terms, the last six as the Democratic Party's leader (Minority Leader) in the Kansas House.  In January 2017, he was a Democratic candidate for the party's nomination as the 4th District of Kansas nominee in the U.S. House of Representatives.  At the Democrats' 4th District nominating convention February 10, 2017, he narrowly lost to James Thompson.
