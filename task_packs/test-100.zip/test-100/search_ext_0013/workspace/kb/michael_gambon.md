# Michael Gambon

Sir Michael John Gambon {'1': ", '2': ", '3': ", '4': "} (born 19 October 1940) is an Irish-born English actor who has worked in theatre, television and film.  Gambon has played the eponymous mystery writer protagonist in the BBC television serial "The Singing Detective", Jules Maigret in the 1990s ITV serial "Maigret", and Professor Albus Dumbledore in the final six "Harry Potter" films after the death of previous actor Richard Harris.  He has won four BAFTA TV Awards and three Olivier Awards.
