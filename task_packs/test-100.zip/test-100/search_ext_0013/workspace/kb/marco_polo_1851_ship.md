# Marco Polo (1851 ship)

Marco Polo was a three-masted wooden clipper ship, launched in 1851 at Saint John, New Brunswick.  She was named after Venetian traveler Marco Polo.  The ship carried emigrants and passengers to Australia and was the first vessel to make the trip in under six months.  Later in her career, the ship was used as a cargo ship before being run aground off Cavendish, Prince Edward Island in 1883.
