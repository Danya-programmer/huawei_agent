import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert sum_num((8, 2, 3, 0, 7))==4.0
        assert sum_num((-10,-20,-30))==-20.0
        assert sum_num((19,15,18))==17.333333333333332

if __name__ == '__main__':
    unittest.main()
