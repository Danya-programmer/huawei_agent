import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert check_email("ankitrai326@gmail.com") == 'Valid Email'
        assert check_email("my.ownsite@ourearth.org") == 'Valid Email'
        assert check_email("ankitaoie326.com") == 'Invalid Email'

if __name__ == '__main__':
    unittest.main()
