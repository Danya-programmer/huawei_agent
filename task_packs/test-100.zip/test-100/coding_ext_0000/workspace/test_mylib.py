import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert radix_sort([15, 79, 25, 68, 37]) == [15, 25, 37, 68, 79]
        assert radix_sort([9, 11, 8, 7, 3, 2]) == [2, 3, 7, 8, 9, 11]
        assert radix_sort([36, 12, 24, 26, 29]) == [12, 24, 26, 29, 36]

if __name__ == '__main__':
    unittest.main()
