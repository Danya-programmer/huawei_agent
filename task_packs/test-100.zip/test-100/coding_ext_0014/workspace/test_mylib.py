import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert count_Digit(12345) == 5
        assert count_Digit(11223305) == 8
        assert count_Digit(4123459) == 7

if __name__ == '__main__':
    unittest.main()
