import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert count_Substring_With_Equal_Ends("abc") == 3
        assert count_Substring_With_Equal_Ends("abcda") == 6
        assert count_Substring_With_Equal_Ends("ab") == 2

if __name__ == '__main__':
    unittest.main()
