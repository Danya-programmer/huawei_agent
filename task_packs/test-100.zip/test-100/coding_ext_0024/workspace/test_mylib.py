import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert second_smallest([1, 2, -8, -2, 0, -2])==-2
        assert second_smallest([1, 1, -0.5, 0, 2, -2, -2])==-0.5
        assert second_smallest([2,2])==None

if __name__ == '__main__':
    unittest.main()
