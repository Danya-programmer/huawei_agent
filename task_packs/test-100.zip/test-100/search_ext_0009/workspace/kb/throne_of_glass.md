# Throne of Glass

Throne of Glass is a young adult high fantasy novel series by American author Sarah J. Maas, beginning with the inaugural entry of the same name.  The story follows the journey of Celaena Sardothien, a teenage assassin in a corrupted kingdom with a tyrannical ruler.  As the tale progresses, Celaena forms unexpected bonds and uncovers a conspiracy amidst her adventures.
