# Duxbury Pier Light

Duxbury Pier lighthouse also called Duxbury Light (nicknamed the "Bug Light") is a lighthouse located in Plymouth Harbor, Massachusetts.  Duxbury Pier Light was built in 1871 on the north side of the main channel in Plymouth Harbor to mark the dangerous shoal off Saquish Head.  The unusual coffeepot-shaped lighthouse is locally known as "Bug Light" or simply "The Bug."  It was the first so-called sparkplug lighthouse in the United States.  Application was made to list the lighthouse on the National Register of Historic Places in 2014.
