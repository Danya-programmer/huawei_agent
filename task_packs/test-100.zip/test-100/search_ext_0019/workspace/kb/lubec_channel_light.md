# Lubec Channel Light

Lubec Channel Light is a sparkplug lighthouse in Lubec, Maine.  Established in 1890, it is one of three surviving sparkplug lights in the state, and served as an important aid to navigation on the St. Croix River It is set in shallow waters in the Lubec Channel, about 500 ft from the Canada–United States border.  The lighthouse was listed on the National Register of Historic Places as Lubec Channel Light Station on March 14, 1988.  The lighthouse was sold by auction into private hands on 2007.
