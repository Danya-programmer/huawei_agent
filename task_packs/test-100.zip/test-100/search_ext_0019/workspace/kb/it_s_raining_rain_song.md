# It's Raining (Rain song)

"It's Raining" is a Korean language song, and the first single from the third album, by Korean R&B singer, Rain.
