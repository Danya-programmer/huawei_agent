# Peck Ledge Light

Peck Ledge Light, also known as "Peck Ledge Lighthouse", is a sparkplug lighthouse in Norwalk, Connecticut, United States, southeast of Norwalk Harbor and northeast of Goose Island among the Norwalk Islands on Long Island Sound.  The lighthouse is about two miles (3 km) from Calf Pasture Beach in Norwalk and can be seen from the beach.
