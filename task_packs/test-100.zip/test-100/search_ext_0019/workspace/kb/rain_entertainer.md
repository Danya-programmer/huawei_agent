# Rain (entertainer)

Jung Ji-hoon (, born June 25, 1982), better known by his stage name Rain (Korean 비 IPA ['piː]), is a South Korean singer-songwriter, actor, and music producer.
