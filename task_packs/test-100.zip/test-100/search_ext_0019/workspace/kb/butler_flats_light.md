# Butler Flats Light

Butler Flats Light is a sparkplug lighthouse located in the outer harbor of New Bedford, Massachusetts, at the mouth of the Acushnet River.  Built in 1898 by the United States Lighthouse Board, it is the only known caisson lighthouse designed by a marine architect.  The light was added to the National Register of Historic Places as Butler Flats Light Station on June 15, 1987.  Automated in 1978, it is now operated by the city as a private aid to navigation.
