# Robbins Reef Light

The Robbins Reef Light Station is a sparkplug lighthouse located off Constable Hook in Bayonne, Hudson County, New Jersey, United States, along the west side of Main Channel, Upper New York Bay.  The tower and integral keepers quarters were built in 1883.  It replaced an octagonal granite tower built in 1839.  The U.S. Coast Guard owned and operated the light station until the 2000s.
