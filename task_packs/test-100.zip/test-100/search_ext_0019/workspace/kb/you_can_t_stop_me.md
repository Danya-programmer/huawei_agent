# You Can't Stop Me

"You Can't Stop Me" is the first single from the Guano Apes' third album, "Walking on a Thin Line".  It was released as a single on January 13, 2003, at which point the album it would appear on was still untitled.  It reached No. 10 in Germany, also charting in four other European countries, and performing well in Portugal.  It was their first single released in the United Kingdom.  The song would later also appear on the 2004 greatest hits album, "Planet of the Apes".
