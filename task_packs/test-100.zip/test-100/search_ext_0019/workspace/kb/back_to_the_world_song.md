# Back to the World (song)

"Back to the World" is the first single from R&B singer Tevin Campbell's third album of the same name.  Written by Jamey Jaz, Rahsaan Patterson and Mikelyn Roderick, it was the only single from his third album to garner decent success on the charts, peaking at #16 on the R&B Charts.  It was also the only single from the album to reach the Hot 100, peaking at #47.  This is Tevin's 10th and last single to date to reach the top 20 on the R&B Charts.
