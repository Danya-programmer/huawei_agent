# Penobscot Bay

Penobscot Bay is an inlet of the Gulf of Maine and Atlantic Ocean in south central Maine.  The bay originates from the mouth of Maine's Penobscot River, downriver from Belfast.  Penobscot Bay has many working waterfronts including Rockland, Rockport, and Stonington, and Belfast upriver.  Penobscot Bay is between Muscongus Bay and Blue Hill Bay, just west of Acadia National Park.
