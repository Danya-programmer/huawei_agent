# Goose Rocks Light

Goose Rocks Light is a sparkplug lighthouse located near North Haven, Maine in Penobscot Bay.  It stands at the eastern entrance to the Fox Islands Thoroughfare, a busy mile-wide passage separating North Haven from Vinalhaven.  Built in 1890, it was added to the National Register of Historic Places as Goose Rocks Light Station on January 21, 1988.  The structure is now privately owned by a preservation group, and remains an active aid to navigation.
