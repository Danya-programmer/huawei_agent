import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert sum_Of_Primes(10) == 17
        assert sum_Of_Primes(20) == 77
        assert sum_Of_Primes(5) == 10

if __name__ == '__main__':
    unittest.main()
