# Avis Rent a Car

Avis is an American car rental company headquartered in Parsippany-Troy Hills, New Jersey, United States.  Avis, Budget Rent a Car and Budget Truck Rental are all units of Avis Budget Group.
