# Chinese Journal of Chemical Physics

The Chinese Journal of Chemical Physics (CJCP) is a peer reviewed journal published by the Chinese Physical Society and hosted by the American Institute of Physics.  It publishes experimental, computational and theoretical research on the interdisciplinary fields of physics, chemistry, biology and materials sciences.  The journal is currently edited by Xue-ming Yang (杨学明) of the Dalian Institute of Chemical Physics, Chinese Academy of Sciences.  CJCP publishes around 120 articles per year via bimonthly issues and has an impact factor of 0.496 (2015).
