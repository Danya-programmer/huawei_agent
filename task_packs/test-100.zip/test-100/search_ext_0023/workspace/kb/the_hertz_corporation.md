# The Hertz Corporation

The Hertz Corporation, a subsidiary of Hertz Global Holdings Inc., is an American car rental company based in Estero, Florida that operates 9,700 international corporate and franchisee locations.  As the second-largest US car rental company by sales, locations, and fleet size, Hertz operates in 150 countries, including North America, Europe, Latin America, Africa, Asia, Australia, The Caribbean, the Middle East, and New Zealand.  The Hertz Corporation owns Dollar and Thrifty Automotive Group - which separates into Thrifty Car Rental and Dollar Rent A Car.
