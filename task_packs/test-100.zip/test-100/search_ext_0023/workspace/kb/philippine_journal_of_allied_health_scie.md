# Philippine Journal of Allied Health Sciences

The Philippine Journal of Allied Health Sciences is the official scientific journal of the University of Santo Tomas' Center for Research on Movement Science and is published biannually.  It is a peer reviewed journal which encourages authors to publish original scholarly articles in the field of human biomechanics, exercise physiology, physical activity in pediatrics and geriatrics, ergonomics, physiologic profiling of athletes, sports injury monitoring, and clinical practice patterns.  The editor in chief is Janine Margarita R. Dizon.
