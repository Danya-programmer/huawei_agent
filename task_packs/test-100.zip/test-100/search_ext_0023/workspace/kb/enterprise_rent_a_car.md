# Enterprise Rent-A-Car

Enterprise Rent-A-Car is an American car rental company headquartered in Clayton, Missouri, United States in Greater St. Louis.  In addition to car rental, Enterprise also oversees commercial fleet management, used car sales, and commercial truck rental operations.
