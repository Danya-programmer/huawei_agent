# Irish Car Rentals

Irish Car Rentals is a car rental company headquartered in Santry, Dublin that provides car rental services in Ireland.  The Irish Car Rentals was the owner of GoCar, the first car sharing service in Ireland and has the Europcar franchise in Ireland.
