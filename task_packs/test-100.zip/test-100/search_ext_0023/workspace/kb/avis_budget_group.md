# Avis Budget Group

Avis Budget Group, Inc. is the American parent company of Avis Car Rental, Budget Car Rental, Budget Truck Rental, Payless Car Rental, Apex Car Rentals, Maggiore Group and Zipcar.  The company's headquarters are located in Parsippany-Troy Hills, New Jersey, United States.
