# Payless Car Rental

Payless Car Rental, Inc. is a car rental company owned by Avis Budget Group and headquartered in St. Petersburg, Florida.  While mainly a franchise system, the company owns and operates several corporate locations.  Payless Car Rental, Payless Car Sales, Payless Parking and REZlink International are sister companies under the umbrella of Avalon Global Group.
