# DNA Research

DNA Research is an international, peer reviewed journal of genomics and DNA research.  The journal was established in 1994, and is published by Oxford University Press on behalf of the Kazusa DNA Research Institute.  The journal is edited by Michio Oishi.
