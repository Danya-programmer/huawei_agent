# Li Fanghua

Li Fanghua (; born 6 January 1932) is a Chinese physicist.  She is a member of the Chinese Academy of Sciences, the World Academy of Sciences, and the International Union of Crystallography.  She is also the director of Chinese Society of Physics and China Union of Crystallography, and an editor of the "Journal of Chinese Electron Microscopy Society", "J. Electron Microscopy", "Chinese Physics Letter", and "Chinese Journal of Physics".
