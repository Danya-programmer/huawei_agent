# Whizzgo

WhizzGo is a United Kingdom car rental company that provides rental cars in more than 258 countries worldwide.  The company started as a pay-by-the-hour service based in the United Kingdom.  Since July 2017 it is restructured and is now providing car rental services by price comparing rates of most of the rent-a-car suppliers worldwide.
