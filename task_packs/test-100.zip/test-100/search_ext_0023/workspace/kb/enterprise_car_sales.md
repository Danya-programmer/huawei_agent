# Enterprise Car Sales

Enterprise Car Sales was established in 1962 by Enterprise Rent-A-Car founder Jack Taylor and is an expanded service of the Enterprise Holdings, the largest rental car company in North America.
