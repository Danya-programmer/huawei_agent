# Budget Rent a Car

Budget Rent a Car System, Inc. is an American car rental company that was founded in 1958 in Los Angeles, California by Morris Mirkin.  Budget's operations are headquartered in Parsippany-Troy Hills, New Jersey.
