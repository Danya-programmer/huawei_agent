# High Noon (2009 film)

High Noon, also known as Nora Roberts' High Noon, is a 2009 television film directed by Peter Markle, which stars Emilie de Ravin and Ivan Sergei.  The film is based on the Nora Roberts novel of the same name and is part of the Nora Roberts 2009 movie collection, which also includes "Northern Lights", "Midnight Bayou", and "Tribute".  The film debuted April 4, 2009 on Lifetime Television.
