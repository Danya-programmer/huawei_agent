# Emilie de Ravin

Emilie de Ravin ( ; born 27 December 1981) is an Australian actress.  She has played Tess Harding on "Roswell" and Claire Littleton on the ABC drama "Lost".  In 2012 she guest-starred as Belle French on the ABC drama "Once Upon a Time" and became a series regular beginning with season two.
