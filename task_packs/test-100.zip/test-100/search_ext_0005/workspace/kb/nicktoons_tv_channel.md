# Nicktoons (TV channel)

Nicktoons is an American digital cable and satellite television channel that is owned by Nickelodeon Group, a unit of the Viacom Media Networks division of Viacom.  Geared towards children and "animation lovers", the channel broadcasts original animated series from sister network Nickelodeon, known as Nicktoons, along with other original animated series, some feature films, and foreign animated programs from Nickelodeon's international networks 24 hours a day.
