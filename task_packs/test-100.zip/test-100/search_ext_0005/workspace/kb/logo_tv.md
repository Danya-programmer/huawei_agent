# Logo TV

Logo TV (often shorted to Logo) is an American digital cable and satellite television channel that is owned by Viacom Media Networks.  Launched in 2005, it was originally aimed primarily at LGBT viewers, but in 2012 it shifted its focus towards general cultural and lifestyle programming.
