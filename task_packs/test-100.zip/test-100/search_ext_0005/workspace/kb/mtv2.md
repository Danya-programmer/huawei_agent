# MTV2

MTV2 (formerly M2) is an American digital cable and satellite television channel owned by Viacom Global Entertainment Group, a unit of the Viacom Media Networks division of Viacom.  The channel was initially broadcast over-the-air in selected markets, where the former all-request music channel known as The Box was broadcast (which was acquired by MTV Networks in 2001 for the sole purpose of conversion to MTV2).
