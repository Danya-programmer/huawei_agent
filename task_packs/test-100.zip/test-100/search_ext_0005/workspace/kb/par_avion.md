# Par Avion

"Par Avion" is the 12th episode of the 3rd season of "Lost" and the 61st episode overall, making it the exact midpoint of the series.  It was aired on March 14, 2007, on ABC.  The episode was written by Christina M. Kim and Jordan Rosenberg and directed by Paul Edwards.  The character of Claire Littleton (Emilie de Ravin) is featured in the episode's flashbacks.
