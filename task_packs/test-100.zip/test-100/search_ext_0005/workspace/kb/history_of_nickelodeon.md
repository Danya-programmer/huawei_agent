# History of Nickelodeon

Nickelodeon is an American basic cable and satellite television network owned by the MTV Networks Kids & Family Group, a unit of the Viacom Media Networks division of Viacom, which focuses on programs aimed at children and teenagers; it has since expanded to include three spin-off digital cable and satellite networks in the United States, and international channels in six continents.
