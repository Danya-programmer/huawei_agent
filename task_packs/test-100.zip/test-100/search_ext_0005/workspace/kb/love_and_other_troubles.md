# Love and Other Troubles

Love and Other Troubles (original Finnish title: "Hulluna Saraan") is a 2012 Finnish romantic comedy film directed by Samuli Valkama.  It stars Emilie de Ravin as Sara, an American line dance teacher, who meets Ville, a 25-year-old former child star, and his father, an ex-rock star, who both fall in love with her.  The film premiered on January 27, 2012 in Finland.
