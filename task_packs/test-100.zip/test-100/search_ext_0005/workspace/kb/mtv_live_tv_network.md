# MTV Live (TV network)

MTV Live (formerly Palladia) is an American digital cable and satellite television network that is owned by Viacom Global Entertainment Group, a unit of the Viacom Media Networks division of Viacom.  The channel, which exclusively broadcasts in 1080i high definition, broadcasts music videos and music-related programming from Viacom-owned networks MTV, MTV Classic, VH1 and CMT, along with other concert and live music programming from outside producers.
