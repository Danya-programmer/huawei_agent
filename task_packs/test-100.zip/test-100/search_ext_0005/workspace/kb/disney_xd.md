# Disney XD

Disney XD is an American digital cable and satellite television channel that is owned by the Disney Channels Worldwide unit of the Disney–ABC Television Group, itself a unit of the Disney Media Networks division of The Walt Disney Company.  Aimed primarily at children ages 6-14, its programming consists of original first-run television series, current and former original series and made-for-cable films from sister network Disney Channel, theatrically-released films, and acquired programs from other distributors.
