# Belle (Once Upon a Time)

Belle Gold (née French), briefly known as Lacey, is a fictional character in ABC's television series "Once Upon a Time".  She is portrayed by Emilie de Ravin, who became a series regular in the second season and onwards after making recurring appearances in the first season, and has become a fan favorite since her debut.  She is both based on the character from "Beauty and the Beast" by Jeanne-Marie Leprince de Beaumont, and the Disney princess of the 1991 film of the same name.
