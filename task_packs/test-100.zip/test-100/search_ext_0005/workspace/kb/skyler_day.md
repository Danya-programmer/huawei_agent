# Skyler Day

Skyler Elizabeth Day (born August 2, 1991) is an American actress and singer.  She is best known for her recurring roles as Maggie Ritter on the TeenNick series "Gigantic" and as Amy Ellis on the NBC series "Parenthood".
