# Belle (Disney)

Belle is a fictional character who appears in Walt Disney Pictures' 30th animated feature film "Beauty and the Beast" (1991).  Originally voiced by American actress and singer Paige O'Hara, Belle is the non-conforming daughter of an inventor.  Belle yearns to abandon her predictable village life in return for adventure.  When her father Maurice is imprisoned by a cold-hearted beast, Belle offers him her own freedom in exchange for her father's, and eventually learns to love the Beast despite his unsightly outward appearance.
