# TeenNick

TeenNick is an American digital cable and satellite television channel that is owned by Nickelodeon Group, a unit of the Viacom Media Networks division of Viacom.  Aimed primarily at teenagers aged 13-18, the channel features a mix of original programming, Nickelodeon-produced series, and acquired programs initially geared towards pre-teens and young teenagers.
