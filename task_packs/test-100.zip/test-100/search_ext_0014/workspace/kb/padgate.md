# Padgate

Padgate is a suburb of the English town and unitary authority of Warrington, Cheshire.  It belongs to the civil parish of Poulton-with-Fearnhead.
