# North East Lincolnshire

North East Lincolnshire is a unitary authority area in the Yorkshire and the Humber region of England, bordering the unitary authority of North Lincolnshire and the non-metropolitan county of Lincolnshire.  The population of the Unitary Authority at the 2011 Census was 159,616.  These three administrative units make up the ceremonial county of Lincolnshire.
