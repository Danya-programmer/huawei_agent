# Honoured Society (Australia)

The Honoured Society (Italian: "Onorata Società" ) is a Calabrian 'Ndrangheta criminal confederation, started in Melbourne and currently active in all Australia.  In 1963, it was reportedly involved in the Victoria Market Murders.  It was led by gangster Frank Benvenuto until his slaying in 2000.  Tony Romeo, another high-ranking member, was shot in 2002.
