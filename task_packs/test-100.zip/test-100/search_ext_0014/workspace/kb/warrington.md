# Warrington

Warrington is a large town and unitary authority area in Cheshire, England, on the banks of the River Mersey, 20 mi east of Liverpool, and 20 mi west of Manchester.  The population in 2016 was estimated at 208,800, more than double that of 1968 when it became a New Town.  Warrington is the largest town in the county of Cheshire.
