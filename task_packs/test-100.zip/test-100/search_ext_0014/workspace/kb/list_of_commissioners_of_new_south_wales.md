# List of Commissioners of New South Wales Police

The Commissioner of the New South Wales Police Force (Known from 1851 to 1926 as the Inspector-General of the New South Wales Police Force) is the head of New South Wales's Police Force.  The post is currently held by Mick Fuller, who replaced Andrew Scipione on 31 March 2017.  The rank is usually referred to as the New South Wales Police Commissioner or simply just "Commissioner".  The New South Wales Police Force has had 22 Commissioners since 1851.
