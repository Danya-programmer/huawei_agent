# Cantref Reservoir

Cantref Reservoir is the middle of the three reservoirs in the Taff Fawr valley in Wales.  It is owned by Welsh Water.  It is located in the Brecon Beacons National Park, mostly in the Powys unitary authority area and within the historic county boundaries of Breconshire.  Part of the south west corner is in the Rhondda Cynon Taff unitary authority area.
