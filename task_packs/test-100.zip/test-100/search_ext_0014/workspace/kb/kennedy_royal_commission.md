# Kennedy Royal Commission

The Royal commission into whether there has been corrupt or criminal conduct by any Western Australian Police Officer, commonly known as the Kennedy Royal Commission, was a Royal Commission established in 2002 by the state government of Western Australia to determine whether any officer of the Western Australia Police had engaged in corrupt or criminal conduct.  The commission issued an interim report on 20 December 2002 and a final report on 30 January 2004.
