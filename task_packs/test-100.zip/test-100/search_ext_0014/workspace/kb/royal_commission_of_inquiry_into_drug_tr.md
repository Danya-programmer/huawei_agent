# Royal Commission of Inquiry into Drug Trafficking

The Royal Commission of Inquiry into Drug Trafficking (1981–1983), also known as the Stewart Royal Commission, was a Royal Commission set up in 1981 by the Commonwealth, Queensland, New South Wales and Victorian governments to inquire into various drug trafficking and related criminal activities of Terence John Clark and his associates.  However, the Commission would spend much of its time examining how criminals were using and abusing the passport system for criminal purposes.
