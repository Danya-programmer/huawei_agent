# Robert Trimbole

Bruno Robert Trimbole (19 March 1931 – 12 May 1987) was an Australian businessman, drug baron and organised crime boss whose was alleged involvement in drug trafficking in the Griffith, New South Wales area, which according to popular loose fiction series Underbelly: Tale of Two Cities, led to a royal commission, a Coroner's inquest and an international chase by the Australian Government seeking his apprehension after he travelled overseas visiting Europe.
