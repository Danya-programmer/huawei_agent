# Llwyn-on Reservoir

Llwyn-on Reservoir is the largest and southernmost of the three reservoirs in the Taff Fawr valley in South Wales.  It is owned by Welsh Water.  It is located in the Brecon Beacons National Park.  The eastern half is in the Merthyr Tydfil unitary authority area and the western half is in the Rhondda Cynon Taff unitary authority area.  The reservoir is within the historic county boundaries of Breconshire.  The dam is adjacent to Llwyn-On village.
