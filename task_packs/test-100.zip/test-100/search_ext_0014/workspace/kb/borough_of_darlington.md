# Borough of Darlington

Darlington is a unitary authority area in the ceremonial county of County Durham, north-east England.  It borders the non-metropolitan county of County Durham to the north and west, Stockton-on-Tees to the east and North Yorkshire to the south along the line of the River Tees.  The urban centre and the base of the borough is the town of Darlington.  In 2011 it had a resident population of 106,000.  The borough is a member of the Tees Valley combined authority area.
