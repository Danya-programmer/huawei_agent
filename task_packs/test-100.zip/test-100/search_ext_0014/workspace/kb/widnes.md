# Widnes

Widnes is an industrial town in the unitary authority of Halton and the ceremonial county of Cheshire in Northwest England.  In 2011 it had a population of 60,221.  Historically in Lancashire, it is on the northern bank of the River Mersey where the estuary narrows to form the Runcorn Gap.  Directly to the south across the Mersey is the town of Runcorn.  Upstream and 8 mi to the east is the town of Warrington, and downstream to the west is Speke, part of the city of Liverpool.
