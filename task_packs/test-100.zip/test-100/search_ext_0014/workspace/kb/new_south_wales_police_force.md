# New South Wales Police Force

The New South Wales Police Force (NSW Police Force; previously the New South Wales Police Service and New South Wales Police) is the primary law enforcement agency of the state of New South Wales, Australia.  It is a servant of the Crown, independent of Government, although a minister of the Crown has administration.  Divided into seventy six local area commands (LAC), the NSW Police Force consists of more than 500 local police stations and covers an area of 801,600 square kilometres in a state of some seven million people.
