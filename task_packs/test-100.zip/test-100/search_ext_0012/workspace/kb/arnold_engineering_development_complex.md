# Arnold Engineering Development Complex

Arnold Engineering Development Complex (AEDC), Arnold Engineering Development Center before July 2012, located at Arnold Air Force Base, Tennessee is a ground-based flight test facility operated by the Air Force Test Center.
