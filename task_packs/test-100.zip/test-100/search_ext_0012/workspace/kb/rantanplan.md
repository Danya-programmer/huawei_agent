# Rantanplan

Rantanplan (alternately spelled Ran-Tan-Plan and Ran Tan Plan) ] is a fictional hound dog created by Belgian comics artist Morris and French writer René Goscinny.  Originally a supporting character in the "Lucky Luke" series, Rantanplan later starred in an eponymous series.  Rantanplan is a spoof of Rin Tin Tin, as idiotic as Rin Tin Tin is clever.  Ironically, in the Turkish translations of the series, he is indeed named Rin Tin Tin.  English versions of the books have renamed him "Rin Tin Can" and "Bushwack" in the 1983 Hanna-Barbera animated Lucky Luke television series.
