# Yippee, Yappee and Yahooey

Yippee, Yappee and Yahooey is a Hanna-Barbera animated television series that premiered September 16, 1964.  It was presented as a segment of "The Peter Potamus Show", along with "Breezly and Sneezly" and "Peter Potamus".
