# Joannes van der Brugghen

Joannes van der Brugghen, known in France as Jean vander Bruggen, (1639 – c. 1740) was a Flemish painter, engraver, art dealer and publisher who was active in Antwerp and Paris.
