# The Jetsons

The Jetsons is an American animated sitcom produced by Hanna-Barbera, originally airing in primetime from September 23, 1962, to March 17, 1963, then later in syndication, with new episodes in 1985 to 1987 as part of "The Funtastic World of Hanna-Barbera" block.  It was Hanna-Barbera's Space Age counterpart to "The Flintstones".
