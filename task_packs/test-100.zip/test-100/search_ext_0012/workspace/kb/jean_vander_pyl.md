# Jean Vander Pyl

Jean Vander Pyl (October 11, 1919 – April 10, 1999) was an American actress on radio, television and movies.  Although her career spanned many decades, she is perhaps best remembered as the voice of Wilma Flintstone for the Hanna-Barbera cartoon "The Flintstones".  In addition to Wilma Flintstone, she also provided the voices of Pebbles Flintstone, Rosie the robot maid on the animated series "The Jetsons", Goldie, Lola Glamour, Nurse LaRue and other characters in "Top Cat", Winsome Witch on "The Secret Squirrel Show" and Ogee on "The Magilla Gorilla Show".
