# Cindy Bear

Cindy Bear is a cartoon character created by Hanna-Barbera Productions.  She is one of the primary supporting characters of the Yogi Bear franchise as well as a regular in the stable of frequently appearing Hanna-Barbera animated personalities.  Cindy was originally portrayed by voice actress Julie Bennett, who reprised the part for most of her appearances from the 1960s through the 1980s.
