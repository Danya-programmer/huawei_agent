# A Flintstones Christmas Carol

A Flintstones Christmas Carol is a 1994 animated television film featuring characters from "The Flintstones" franchise, and based on the novel "A Christmas Carol" by Charles Dickens.  Produced by Hanna-Barbera, it features the voices of Henry Corden, Jean Vander Pyl and Frank Welker.  It first aired November 21, 1994 on ABC.
