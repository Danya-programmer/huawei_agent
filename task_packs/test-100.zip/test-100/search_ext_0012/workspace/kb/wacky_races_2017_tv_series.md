# Wacky Races (2017 TV series)

Wacky Races is an American animated children's television series created by Rebecca Himot and Tramm Wigzell.  It is a remake of the 1968 Hanna-Barbera animated series "Wacky Races" and is the first television series to be directly produced by Hanna-Barbera since "I Am Weasel".  The show debuted on Boomerang's SVOD service in the United States, and will premiere internationally in 2017.
