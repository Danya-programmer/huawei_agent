# George W. Weightman

Major General George W. Weightman was a U.S. Army Family Medicine physician who was commander of the North Atlantic Regional Medical Command and Walter Reed Army Medical Center (WRAMC).  He was relieved of his WRAMC command on March 1, 2007, in the wake of the Walter Reed Army Medical Center neglect scandal.  He took command of the U.S. Army Medical Research and Materiel Command in November 2007 and retired from active duty on 31 March 2009.
