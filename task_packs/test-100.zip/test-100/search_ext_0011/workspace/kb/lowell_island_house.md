# Lowell Island House

Lowell Island House was a nineteenth-century hotel on Lowell Island (now known as Children's Island), which comprises a part of Salem, Massachusetts.  The island is geographically closer to the city of Marblehead than it is to mainland Salem.
