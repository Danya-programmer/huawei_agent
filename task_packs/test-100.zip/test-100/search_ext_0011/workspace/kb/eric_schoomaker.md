# Eric Schoomaker

Eric B. Schoomaker (born September 15, 1948) is a former United States Army lieutenant general who served as the 42nd Surgeon General of the United States Army and Commanding General, United States Army Medical Command, and a practicing hematologist.  He previously served as Commanding General, North Atlantic Regional Medical Command and Walter Reed Army Medical Center.  He assumed the post of U.S. Army Surgeon General on December 11, 2007.
