# Ahtme

Ahtme is a settlement in Ida-Viru County, Estonia with a population of around 18,000.  It is administered as the second major district of the town of Kohtla-Järve, despite being separate from the central district of Järve and geographically closer to the independent town of Jõhvi, located directly to the north.  Ahtme was an independent town from 1953 to 1960.  The economy is centered on the oil shale industry.
