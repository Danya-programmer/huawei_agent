# Sphyranthera

Sphyranthera is a plant genus of the family Euphorbiaceae and the only genus of its tribe (Sphyranthereae).  It was first described in 1887.  The entire genus is endemic to the Andaman & Nicobar Islands in the Bay of Bengal, politically part of India but geographically closer to Myanmar.
