# Walter Reed Health Care System

The Walter Reed Health Care System (WRHCS) is the United States Army's comprehensive and integrated health care delivery system for the National Capital Region.  It provides the full range of health care to members of the military and their families as well as members of the federal government.  The WRHCS encompasses the Walter Reed Army Medical Center and seven other Army hospitals and health care clinics in Maryland, Pennsylvania, and Virginia.
