# Doro (musician)

Dorothee Pesch (born 3 June 1964), popularly known as Doro Pesch or Doro, is a German heavy metal singer-songwriter, formerly front-woman of the heavy metal band Warlock.  The name Doro has also been associated with the touring band accompanying the singer, whose members have continuously changed in more than twenty years of uninterrupted activity, the most stable presences being those of bassist Nick Douglas and drummer Johnny Dee.
