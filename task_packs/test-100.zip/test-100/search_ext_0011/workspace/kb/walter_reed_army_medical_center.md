# Walter Reed Army Medical Center

The Walter Reed Army Medical Center (WRAMC) — known as Walter Reed General Hospital (WRGH) until 1951 — was the U.S. Army's flagship medical center from 1909 to 2011.  Located on 113 acre in Washington, D.C., it served more than 150,000 active and retired personnel from all branches of the military.  The center was named after Major Walter Reed (1851–1902), an army physician who led the team that confirmed that yellow fever is transmitted by mosquitoes rather than direct contact.
