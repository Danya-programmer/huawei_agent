# Army Medical School

Founded by U.S. Army Brigadier General George Miller Sternberg, MD in 1893, the Army Medical School (AMS) was by some reckonings the world's first school of public health and preventive medicine.  (The other institution vying for this distinction is the Johns Hopkins School of Public Health (1916).)  The AMS ultimately became the Army Medical Center (1923), then the Walter Reed Army Institute of Research (1953).
