# 1927 Memorial Cup

The 1927 Memorial Cup final was the ninth junior ice hockey championship of the Canadian Amateur Hockey Association.  The George Richardson Memorial Trophy champions Owen Sound Greys of the Ontario Hockey Association in Eastern Canada competed against the Abbott Cup champions Port Arthur West Ends of the Thunder Bay Junior Hockey League in Western Canada.  The series was the first to feature two Ontario-based teams.  Teams from Port Arthur and Fort William (later amalgamated into Thunder Bay), competed with geographically closer western teams, rather than eastern teams.
