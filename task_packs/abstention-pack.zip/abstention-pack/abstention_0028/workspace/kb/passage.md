# Passage

Sky UK Limited (formerly British Sky Broadcasting or BSkyB) is a British telecommunications company which serves the United Kingdom. Sky provides television and broadband internet services and fixed line telephone services to consumers and businesses in the United Kingdom. It is the UK's largest pay-TV broadcaster with 11 million customers as of 2015. It was the UK's most popular digital TV service until it was overtaken by Freeview in April 2007. Its corporate headquarters are based in Isleworth.
