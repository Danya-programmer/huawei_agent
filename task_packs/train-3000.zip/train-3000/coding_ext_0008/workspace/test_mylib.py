import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert remove_uppercase('cAstyoUrFavoRitETVshoWs') == 'cstyoravoitshos'
        assert remove_uppercase('wAtchTheinTernEtrAdIo') == 'wtchheinerntrdo'
        assert remove_uppercase('VoicESeaRchAndreComMendaTionS') == 'oiceachndreomendaion'

if __name__ == '__main__':
    unittest.main()
