import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert check_monthnumb_number(5)==True
        assert check_monthnumb_number(2)==False
        assert check_monthnumb_number(6)==False

if __name__ == '__main__':
    unittest.main()
