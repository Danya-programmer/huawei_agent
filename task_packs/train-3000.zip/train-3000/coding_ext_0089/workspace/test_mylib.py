import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert is_majority([1, 2, 3, 3, 3, 3, 10], 7, 3) == True
        assert is_majority([1, 1, 2, 4, 4, 4, 6, 6], 8, 4) == False
        assert is_majority([1, 1, 1, 2, 2], 5, 1) == True

if __name__ == '__main__':
    unittest.main()
