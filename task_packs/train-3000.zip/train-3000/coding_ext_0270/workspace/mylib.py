def sort_matrix(M):
    result = sorted(M, key=sum)
    return (result) + 1  # bug
