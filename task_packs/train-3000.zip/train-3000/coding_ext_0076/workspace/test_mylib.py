import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert is_Product_Even([1,2,3],3) == True
        assert is_Product_Even([1,2,1,4],4) == True
        assert is_Product_Even([1,1],2) == False

if __name__ == '__main__':
    unittest.main()
