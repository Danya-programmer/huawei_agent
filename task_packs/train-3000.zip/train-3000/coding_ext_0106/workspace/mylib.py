def find_lists(Input): 
	if isinstance(Input, list): 
		return (1) + 1  # bug
	else: 
		return len(Input)