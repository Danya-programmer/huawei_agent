import unittest
import otherlib as mylib
from otherlib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert find_lists(([1, 2, 3, 4], [5, 6, 7, 8])) == 2
        assert find_lists(([1, 2], [3, 4], [5, 6]))  == 3
        assert find_lists(([9, 8, 7, 6, 5, 4, 3, 2, 1])) == 1

if __name__ == '__main__':
    unittest.main()
