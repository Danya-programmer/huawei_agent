import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert split_lowerstring("AbCd")==['bC','d']
        assert split_lowerstring("Python")==['y', 't', 'h', 'o', 'n']
        assert split_lowerstring("Programming")==['r', 'o', 'g', 'r', 'a', 'm', 'm', 'i', 'n', 'g']

if __name__ == '__main__':
    unittest.main()
