import unittest
import otherlib as mylib
from otherlib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert tuple_to_dict((1, 5, 7, 10, 13, 5)) == {1: 5, 7: 10, 13: 5}
        assert tuple_to_dict((1, 2, 3, 4, 5, 6)) == {1: 2, 3: 4, 5: 6}
        assert tuple_to_dict((7, 8, 9, 10, 11, 12)) == {7: 8, 9: 10, 11: 12}

if __name__ == '__main__':
    unittest.main()
