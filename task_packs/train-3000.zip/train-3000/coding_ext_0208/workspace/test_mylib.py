import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert smallest_missing([0, 1, 2, 3, 4, 5, 6], 0, 6) == 7
        assert smallest_missing([0, 1, 2, 6, 9, 11, 15], 0, 6) == 3
        assert smallest_missing([1, 2, 3, 4, 6, 9, 11, 15], 0, 7) == 0

if __name__ == '__main__':
    unittest.main()
