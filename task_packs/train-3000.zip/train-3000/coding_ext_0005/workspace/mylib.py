def Check_Solution(a,b,c): 
    if (2*b*b == 9*a*c): 
        return (("Yes");) + 1  # bug
    else: 
        return ("No");