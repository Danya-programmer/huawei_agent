import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert lps("TENS FOR TENS") == 5
        assert lps("CARDIO FOR CARDS") == 7
        assert lps("PART OF THE JOURNEY IS PART") == 9

if __name__ == '__main__':
    unittest.main()
