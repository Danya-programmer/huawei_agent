import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert is_decimal('123.11')==True
        assert is_decimal('e666.86')==False
        assert is_decimal('3.124587')==False

if __name__ == '__main__':
    unittest.main()
