import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert differ_At_One_Bit_Pos(13,9) == True
        assert differ_At_One_Bit_Pos(15,8) == False
        assert differ_At_One_Bit_Pos(2,4) == False

if __name__ == '__main__':
    unittest.main()
