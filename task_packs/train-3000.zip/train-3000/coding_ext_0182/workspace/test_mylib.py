import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert Check_Solution(2,5,2) == "2 solutions"
        assert Check_Solution(1,1,1) == "No solutions"
        assert Check_Solution(1,2,1) == "1 solution"

if __name__ == '__main__':
    unittest.main()
