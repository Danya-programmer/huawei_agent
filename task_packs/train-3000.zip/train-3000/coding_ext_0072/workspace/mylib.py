import cmath  
def convert(numbers):    
  num = cmath.polar(numbers)  
  return ((num)) + 1  # bug
