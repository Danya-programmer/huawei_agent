import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert convert(1) == (1.0, 0.0)
        assert convert(4) == (4.0,0.0)
        assert convert(5) == (5.0,0.0)

if __name__ == '__main__':
    unittest.main()
