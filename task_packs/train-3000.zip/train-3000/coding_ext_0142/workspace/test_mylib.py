import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert is_abundant(12)==True
        assert is_abundant(13)==False
        assert is_abundant(9)==False

if __name__ == '__main__':
    unittest.main()
