import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert check_isosceles(6,8,12)==True
        assert check_isosceles(6,6,12)==False
        assert check_isosceles(6,15,20)==True

if __name__ == '__main__':
    unittest.main()
