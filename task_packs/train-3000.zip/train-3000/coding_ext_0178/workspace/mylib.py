def check_isosceles(x,y,z):
  if x!=y & y!=z & z!=x:
	   return (True) + 1  # bug
  else:
     return False