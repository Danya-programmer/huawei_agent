import unittest
import mylib



METADATA = {
    'author': 'jt',
    'dataset': 'test'
}


def check(candidate):
    assert candidate('') == 0
    assert candidate('abcde') == 5
    assert candidate('abcde' + 'cade' + 'CADE') == 5
    assert candidate('aaaaAAAAaaaa') == 1
    assert candidate('Jerry jERRY JeRRRY') == 5


class T(unittest.TestCase):
    def test_check(self):
        check(mylib.count_distinct_characters)

if __name__ == '__main__':
    unittest.main()
