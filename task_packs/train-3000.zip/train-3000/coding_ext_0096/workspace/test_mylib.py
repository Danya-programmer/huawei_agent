import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert highest_Power_of_2(10) == 8
        assert highest_Power_of_2(19) == 16
        assert highest_Power_of_2(32) == 32

if __name__ == '__main__':
    unittest.main()
