import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert neg_nos([-1,4,5,-6]) == [-1,-6]
        assert neg_nos([-1,-2,3,4]) == [-1,-2]
        assert neg_nos([-7,-6,8,9]) == [-7,-6]

if __name__ == '__main__':
    unittest.main()
