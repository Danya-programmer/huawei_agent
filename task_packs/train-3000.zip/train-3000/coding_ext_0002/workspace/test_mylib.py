import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert set_left_most_unset_bit(10) == 14
        assert set_left_most_unset_bit(12) == 14
        assert set_left_most_unset_bit(15) == 15

if __name__ == '__main__':
    unittest.main()
