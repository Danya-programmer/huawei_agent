import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert replace_spaces('Jumanji The Jungle') == 'Jumanji_The_Jungle'
        assert replace_spaces('The_Avengers') == 'The Avengers'
        assert replace_spaces('Fast and Furious') == 'Fast_and_Furious'

if __name__ == '__main__':
    unittest.main()
