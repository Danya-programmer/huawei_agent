import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert count_unset_bits(2) == 1
        assert count_unset_bits(4) == 2
        assert count_unset_bits(6) == 1

if __name__ == '__main__':
    unittest.main()
