import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert even_or_odd("AB3454D") =="Odd"
        assert even_or_odd("ABC") == "Even"
        assert even_or_odd("AAD") == "Odd"

if __name__ == '__main__':
    unittest.main()
