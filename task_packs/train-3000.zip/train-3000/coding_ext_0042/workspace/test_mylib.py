import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert volume_tetrahedron(10)==117.85
        assert volume_tetrahedron(15)==397.75
        assert volume_tetrahedron(20)==942.81

if __name__ == '__main__':
    unittest.main()
