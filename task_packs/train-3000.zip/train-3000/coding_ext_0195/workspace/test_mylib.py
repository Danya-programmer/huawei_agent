import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert pos_count([1,-2,3,-4]) == 2
        assert pos_count([3,4,5,-1]) == 3
        assert pos_count([1,2,3,4]) == 4

if __name__ == '__main__':
    unittest.main()
