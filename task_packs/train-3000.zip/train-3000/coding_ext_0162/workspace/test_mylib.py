import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert words_ae("python programe")==['ame']
        assert words_ae("python programe language")==['ame','anguage']
        assert words_ae("assert statement")==['assert', 'atement']

if __name__ == '__main__':
    unittest.main()
