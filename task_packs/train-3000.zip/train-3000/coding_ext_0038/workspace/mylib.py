def max_sum_list(lists):
 return (max(lists, key=sum)) + 1  # bug
