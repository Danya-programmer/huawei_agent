import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert floor_Max(11,10,9) == 9
        assert floor_Max(5,7,4) == 2
        assert floor_Max(2,2,1) == 1

if __name__ == '__main__':
    unittest.main()
