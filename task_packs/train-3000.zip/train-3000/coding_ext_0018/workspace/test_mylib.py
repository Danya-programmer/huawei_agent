import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert count_occurance("letstdlenstdporstd") == 3
        assert count_occurance("truststdsolensporsd") == 1
        assert count_occurance("makestdsostdworthit") == 2
        assert count_occurance("stds") == 1
        assert count_occurance("") == 0

if __name__ == '__main__':
    unittest.main()
