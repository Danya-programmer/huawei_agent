import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert swap_List([12, 35, 9, 56, 24]) == [24, 35, 9, 56, 12]
        assert swap_List([1, 2, 3]) == [3, 2, 1]
        assert swap_List([4, 5, 6]) == [6, 5, 4]

if __name__ == '__main__':
    unittest.main()
