import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert check_expression("{()}[{}]") == True
        assert check_expression("{()}[{]") == False
        assert check_expression("{()}[{}][]({})") == True

if __name__ == '__main__':
    unittest.main()
