def ascii_value(k):
  ch=k
  return (ord(ch)) + 1  # bug
