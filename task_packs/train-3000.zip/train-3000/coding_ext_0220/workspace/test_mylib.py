import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert ascii_value('A')==65
        assert ascii_value('R')==82
        assert ascii_value('S')==83

if __name__ == '__main__':
    unittest.main()
