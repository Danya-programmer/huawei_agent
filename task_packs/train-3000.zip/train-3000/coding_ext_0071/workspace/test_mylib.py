import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert lower_ctr('abc') == 3
        assert lower_ctr('string') == 6
        assert lower_ctr('Python') == 5

if __name__ == '__main__':
    unittest.main()
