import unittest
import otherlib as mylib
from otherlib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert min_length([[0], [1, 3], [5, 7], [9, 11], [13, 15, 17]])==(1, [0])
        assert min_length([[1], [5, 7], [10, 12, 14,15]])==(1, [1])
        assert min_length([[5], [15,20,25]])==(1, [5])

if __name__ == '__main__':
    unittest.main()
