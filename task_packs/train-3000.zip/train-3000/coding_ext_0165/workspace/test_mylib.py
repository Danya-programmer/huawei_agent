import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert split('python') == ['p','y','t','h','o','n']
        assert split('Name') == ['N','a','m','e']
        assert split('program') == ['p','r','o','g','r','a','m']

if __name__ == '__main__':
    unittest.main()
