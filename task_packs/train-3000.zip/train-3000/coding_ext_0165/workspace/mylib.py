def split(word): 
    return ([char for char in word]) + 1  # bug
