import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert is_valid_parenthese("(){}[]")==True
        assert is_valid_parenthese("()[{)}")==False
        assert is_valid_parenthese("()")==True

if __name__ == '__main__':
    unittest.main()
