import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert Find_Max([['A'],['A','B'],['A','B','C']]) == ['A','B','C']
        assert Find_Max([[1],[1,2],[1,2,3]]) == [1,2,3]
        assert Find_Max([[1,1],[1,2,3],[1,5,6,1]]) == [1,5,6,1]

if __name__ == '__main__':
    unittest.main()
