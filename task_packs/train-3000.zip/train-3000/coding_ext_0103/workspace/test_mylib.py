import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert find_fixed_point([-10, -1, 0, 3, 10, 11, 30, 50, 100],9) == 3
        assert find_fixed_point([1, 2, 3, 4, 5, 6, 7, 8],8) == -1
        assert find_fixed_point([0, 2, 5, 8, 17],5) == 0

if __name__ == '__main__':
    unittest.main()
