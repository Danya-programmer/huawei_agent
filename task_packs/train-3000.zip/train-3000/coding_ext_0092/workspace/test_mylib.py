import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert square_Sum(2) == 20
        assert square_Sum(3) == 56
        assert square_Sum(4) == 120

if __name__ == '__main__':
    unittest.main()
