import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert insert_element(['Red', 'Green', 'Black'] ,'c')==['c', 'Red', 'c', 'Green', 'c', 'Black'] 
        assert insert_element(['python', 'java'] ,'program')==['program', 'python', 'program', 'java'] 
        assert insert_element(['happy', 'sad'] ,'laugh')==['laugh', 'happy', 'laugh', 'sad'] 

if __name__ == '__main__':
    unittest.main()
