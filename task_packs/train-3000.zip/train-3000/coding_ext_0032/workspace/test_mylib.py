import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert test_duplicate(([1,2,3,4,5]))==False
        assert test_duplicate(([1,2,3,4, 4]))==True
        assert test_duplicate([1,1,2,2,3,3,4,4,5])==True

if __name__ == '__main__':
    unittest.main()
