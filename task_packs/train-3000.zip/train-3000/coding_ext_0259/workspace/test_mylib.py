import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert upper_ctr('PYthon') == 1
        assert upper_ctr('BigData') == 1
        assert upper_ctr('program') == 0

if __name__ == '__main__':
    unittest.main()
