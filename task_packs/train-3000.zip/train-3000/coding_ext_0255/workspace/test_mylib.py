import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert find_Parity(12) == False
        assert find_Parity(7) == True
        assert find_Parity(10) == False

if __name__ == '__main__':
    unittest.main()
