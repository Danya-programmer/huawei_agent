import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert max_of_three(10,20,30)==30
        assert max_of_three(55,47,39)==55
        assert max_of_three(10,49,30)==49

if __name__ == '__main__':
    unittest.main()
