import unittest
import mylib



METADATA = {}


def check(candidate):
    assert candidate([1, 2, 4, 10], 100)
    assert not candidate([1, 20, 4, 10], 5)
    assert candidate([1, 20, 4, 10], 21)
    assert candidate([1, 20, 4, 10], 22)
    assert candidate([1, 8, 4, 10], 11)
    assert not candidate([1, 8, 4, 10], 10)



class T(unittest.TestCase):
    def test_check(self):
        check(mylib.below_threshold)

if __name__ == '__main__':
    unittest.main()
