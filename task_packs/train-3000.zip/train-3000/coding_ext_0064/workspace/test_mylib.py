import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert max_sub_array_sum_repeated([10, 20, -30, -1], 4, 3) == 30
        assert max_sub_array_sum_repeated([-1, 10, 20], 3, 2) == 59
        assert max_sub_array_sum_repeated([-1, -2, -3], 3, 3) == -1

if __name__ == '__main__':
    unittest.main()
