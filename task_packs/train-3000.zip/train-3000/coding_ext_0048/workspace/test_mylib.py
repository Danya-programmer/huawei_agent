import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert check_distinct((1, 4, 5, 6, 1, 4)) == False
        assert check_distinct((1, 4, 5, 6)) == True
        assert check_distinct((2, 3, 4, 5, 6)) == True

if __name__ == '__main__':
    unittest.main()
