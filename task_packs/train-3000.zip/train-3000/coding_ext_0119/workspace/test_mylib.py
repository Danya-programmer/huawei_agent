import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert sum_Of_product(3) == 15
        assert sum_Of_product(4) == 56
        assert sum_Of_product(1) == 1

if __name__ == '__main__':
    unittest.main()
