import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert dealnnoy_num(3, 4) == 129
        assert dealnnoy_num(3, 3) == 63
        assert dealnnoy_num(4, 5) == 681

if __name__ == '__main__':
    unittest.main()
