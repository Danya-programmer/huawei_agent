import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert sector_area(4,45)==6.283185307179586
        assert sector_area(9,45)==31.808625617596654
        assert sector_area(9,361)==None

if __name__ == '__main__':
    unittest.main()
