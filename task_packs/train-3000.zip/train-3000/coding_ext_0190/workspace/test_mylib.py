import unittest
import otherlib as mylib
from otherlib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert count_occurance("letstdlenstdporstd") == 3
        assert count_occurance("truststdsolensporsd") == 1
        assert count_occurance("makestdsostdworthit") == 2

if __name__ == '__main__':
    unittest.main()
