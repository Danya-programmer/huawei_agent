import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert sum_positivenum([2, 4, -6, -9, 11, -12, 14, -5, 17])==48
        assert sum_positivenum([10,15,-14,13,-18,12,-20])==50
        assert sum_positivenum([19, -65, 57, 39, 152,-639, 121, 44, 90, -190])==522

if __name__ == '__main__':
    unittest.main()
