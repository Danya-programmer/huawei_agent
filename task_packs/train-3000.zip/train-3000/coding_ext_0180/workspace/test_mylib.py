import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert check_Even_Parity(10) == True
        assert check_Even_Parity(11) == False
        assert check_Even_Parity(18) == True

if __name__ == '__main__':
    unittest.main()
