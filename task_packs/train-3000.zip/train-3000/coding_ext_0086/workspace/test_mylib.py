import unittest
import otherlib as mylib
from otherlib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert text_match_two_three("ac")==(False)
        assert text_match_two_three("dc")==(False)
        assert text_match_two_three("abbbba")==(True)

if __name__ == '__main__':
    unittest.main()
