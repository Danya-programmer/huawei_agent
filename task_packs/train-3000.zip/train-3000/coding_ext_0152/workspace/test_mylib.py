import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert next_smallest_palindrome(99)==101
        assert next_smallest_palindrome(1221)==1331
        assert next_smallest_palindrome(120)==121

if __name__ == '__main__':
    unittest.main()
