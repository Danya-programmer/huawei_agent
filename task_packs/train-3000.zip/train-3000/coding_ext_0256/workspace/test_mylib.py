import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert check_alphanumeric("dawood@") == 'Discard'
        assert check_alphanumeric("skdmsam326") == 'Accept'
        assert check_alphanumeric("cooltricks@") == 'Discard'

if __name__ == '__main__':
    unittest.main()
