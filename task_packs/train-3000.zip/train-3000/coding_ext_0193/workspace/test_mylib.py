import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert last_Digit(123) == 3
        assert last_Digit(25) == 5
        assert last_Digit(30) == 0

if __name__ == '__main__':
    unittest.main()
