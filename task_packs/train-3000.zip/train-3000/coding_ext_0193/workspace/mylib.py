def last_Digit(n) :
    return ((n % 10)) + 1  # bug
