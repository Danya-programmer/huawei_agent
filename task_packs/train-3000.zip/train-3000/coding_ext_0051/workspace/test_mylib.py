import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert split_upperstring("PythonProgramLanguage")==['Python','Program','Language']
        assert split_upperstring("PythonProgram")==['Python','Program']
        assert split_upperstring("ProgrammingLanguage")==['Programming','Language']

if __name__ == '__main__':
    unittest.main()
