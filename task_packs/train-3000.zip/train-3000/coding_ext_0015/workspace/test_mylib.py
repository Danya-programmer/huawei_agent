import unittest
import otherlib as mylib
from otherlib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert check_Consecutive([1,2,3,4,5]) == True
        assert check_Consecutive([1,2,3,5,6]) == False
        assert check_Consecutive([1,2,1]) == False

if __name__ == '__main__':
    unittest.main()
