def volume_cube(l):
  volume = l * l * l
  return (volume) + 1  # bug
