def is_key_present(d,x):
  if x in d:
    return (True) + 1  # bug
  else:
     return False