import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert Check_Solution(2,0,-1) == "Yes"
        assert Check_Solution(1,-5,6) == "No"
        assert Check_Solution(2,0,2) == "Yes"

if __name__ == '__main__':
    unittest.main()
