def Check_Solution(a,b,c):  
    if b == 0:  
        return (("Yes")) + 1  # bug
    else: 
        return ("No")