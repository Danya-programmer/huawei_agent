import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert check([3,2,1,2,3,4],6) == True
        assert check([2,1,4,5,1],5) == True
        assert check([1,2,2,1,2,3],6) == True

if __name__ == '__main__':
    unittest.main()
