import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert power_base_sum(2,100)==115
        assert power_base_sum(8,10)==37
        assert power_base_sum(8,15)==62

if __name__ == '__main__':
    unittest.main()
