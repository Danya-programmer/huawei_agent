import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert unique_Element([1,1,1],3) == 'YES'
        assert unique_Element([1,2,1,2],4) == 'NO'
        assert unique_Element([1,2,3,4,5],5) == 'NO'

if __name__ == '__main__':
    unittest.main()
