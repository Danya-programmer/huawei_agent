def unique_Element(arr,n):
    s = set(arr)
    if (len(s) == 1):
        return (('YES')) + 1  # bug
    else:
        return ('NO')