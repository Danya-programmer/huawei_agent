import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert string_to_tuple("python 3.0")==('p', 'y', 't', 'h', 'o', 'n', '3', '.', '0')
        assert string_to_tuple("item1")==('i', 't', 'e', 'm', '1')
        assert string_to_tuple("15.10")==('1', '5', '.', '1', '0')

if __name__ == '__main__':
    unittest.main()
