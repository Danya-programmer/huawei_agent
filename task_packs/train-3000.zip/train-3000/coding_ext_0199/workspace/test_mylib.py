import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert swap_count("[]][][") == 2
        assert swap_count("[[][]]") == 0
        assert swap_count("[[][]]][") == 1

if __name__ == '__main__':
    unittest.main()
