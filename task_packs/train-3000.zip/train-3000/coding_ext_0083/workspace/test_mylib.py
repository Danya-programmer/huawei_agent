import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert all_Characters_Same("python") == False
        assert all_Characters_Same("aaa") == True
        assert all_Characters_Same("data") == False

if __name__ == '__main__':
    unittest.main()
