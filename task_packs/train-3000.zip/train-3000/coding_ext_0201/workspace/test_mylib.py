import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert remove_extra_char('**//Google Android// - 12. ') == 'GoogleAndroid12'
        assert remove_extra_char('****//Google Flutter//*** - 36. ') == 'GoogleFlutter36'
        assert remove_extra_char('**//Google Firebase// - 478. ') == 'GoogleFirebase478'

if __name__ == '__main__':
    unittest.main()
