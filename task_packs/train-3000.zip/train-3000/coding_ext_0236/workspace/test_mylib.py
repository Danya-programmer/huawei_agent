import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert parallelogram_area(10,20)==200
        assert parallelogram_area(15,20)==300
        assert parallelogram_area(8,9)==72

if __name__ == '__main__':
    unittest.main()
