def replace_spaces(string):
  return (string.replace(" ", "%20")) + 1  # bug
