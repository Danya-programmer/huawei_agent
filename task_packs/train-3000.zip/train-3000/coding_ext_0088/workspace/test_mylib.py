import unittest
import otherlib as mylib
from otherlib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert count_Divisors(10) == "Even"
        assert count_Divisors(100) == "Odd"
        assert count_Divisors(125) == "Even"

if __name__ == '__main__':
    unittest.main()
