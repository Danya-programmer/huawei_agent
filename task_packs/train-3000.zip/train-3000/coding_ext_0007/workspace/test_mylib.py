import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert min_Ops([2,2,2,2],4,3) == 0
        assert min_Ops([4,2,6,8],4,3) == -1
        assert min_Ops([21,33,9,45,63],5,6) == 24

if __name__ == '__main__':
    unittest.main()
