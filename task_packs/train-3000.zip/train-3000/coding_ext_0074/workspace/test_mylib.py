import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert check_char("abba") == "Valid"
        assert check_char("a") == "Valid"
        assert check_char("abcd") == "Invalid"

if __name__ == '__main__':
    unittest.main()
