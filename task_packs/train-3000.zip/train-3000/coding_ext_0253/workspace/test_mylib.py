import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert find_star_num(3) == 37
        assert find_star_num(4) == 73
        assert find_star_num(5) == 121

if __name__ == '__main__':
    unittest.main()
