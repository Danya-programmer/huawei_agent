import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert modular_inverse([ 1, 6, 4, 5 ], 4, 7) == 2
        assert modular_inverse([1, 3, 8, 12, 12], 5, 13) == 3
        assert modular_inverse([2, 3, 4, 5], 4, 6) == 1

if __name__ == '__main__':
    unittest.main()
