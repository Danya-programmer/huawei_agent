import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert multiply_list([1,-2,3]) == -6
        assert multiply_list([1,2,3,4]) == 24
        assert multiply_list([3,1,2,3]) == 18

if __name__ == '__main__':
    unittest.main()
