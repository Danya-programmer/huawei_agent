import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert odd_values_string('abcdef') == 'ace'
        assert odd_values_string('python') == 'pto'
        assert odd_values_string('data') == 'dt'
        assert odd_values_string('lambs') == 'lms'

if __name__ == '__main__':
    unittest.main()
