import unittest
import otherlib as mylib
from otherlib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert max_sum([[1], [2,1], [3,3,2]], 3) == 6
        assert max_sum([[1], [1, 2], [4, 1, 12]], 3) == 15 
        assert max_sum([[2], [3,2], [13,23,12]], 3) == 28

if __name__ == '__main__':
    unittest.main()
