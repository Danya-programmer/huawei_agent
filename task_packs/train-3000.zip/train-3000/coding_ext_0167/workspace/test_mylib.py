import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert remove_odd([1,2,3]) == [2]
        assert remove_odd([2,4,6]) == [2,4,6]
        assert remove_odd([10,20,3]) == [10,20]

if __name__ == '__main__':
    unittest.main()
