import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert new_tuple(["WEB", "is"], "best") == ('WEB', 'is', 'best')
        assert new_tuple(["We", "are"], "Developers") == ('We', 'are', 'Developers')
        assert new_tuple(["Part", "is"], "Wrong") == ('Part', 'is', 'Wrong')

if __name__ == '__main__':
    unittest.main()
