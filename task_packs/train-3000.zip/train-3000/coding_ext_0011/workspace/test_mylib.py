import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert capital_words_spaces("Python") == 'Python'
        assert capital_words_spaces("PythonProgrammingExamples") == 'Python Programming Examples'
        assert capital_words_spaces("GetReadyToBeCodingFreak") == 'Get Ready To Be Coding Freak'

if __name__ == '__main__':
    unittest.main()
