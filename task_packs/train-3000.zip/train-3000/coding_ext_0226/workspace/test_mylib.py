import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert is_lower("InValid") == "invalid"
        assert is_lower("TruE") == "true"
        assert is_lower("SenTenCE") == "sentence"

if __name__ == '__main__':
    unittest.main()
