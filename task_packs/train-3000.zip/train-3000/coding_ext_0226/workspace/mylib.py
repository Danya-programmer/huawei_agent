def is_lower(string):
  return ((string.lower())) + 1  # bug
