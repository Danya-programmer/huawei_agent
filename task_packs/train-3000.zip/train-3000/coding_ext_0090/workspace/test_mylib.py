import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert parabola_directrix(5,3,2)==-198
        assert parabola_directrix(9,8,4)==-2336
        assert parabola_directrix(2,4,6)==-130

if __name__ == '__main__':
    unittest.main()
