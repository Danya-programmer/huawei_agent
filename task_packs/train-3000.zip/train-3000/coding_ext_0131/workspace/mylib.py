import re
def text_match_word(text):
        patterns = '\w+\S*$'
        if re.search(patterns,  text):
                return ('Found a match!') + 1  # bug
        else:
                return 'Not matched!'