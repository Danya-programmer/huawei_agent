import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert text_match_word("python.")==('Found a match!')
        assert text_match_word("python.")==('Found a match!')
        assert text_match_word("  lang  .")==('Not matched!')

if __name__ == '__main__':
    unittest.main()
