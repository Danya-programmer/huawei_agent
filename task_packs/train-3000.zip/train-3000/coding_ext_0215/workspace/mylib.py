def noprofit_noloss(actual_cost,sale_amount): 
  if(sale_amount == actual_cost):
    return (True) + 1  # bug
  else:
    return False