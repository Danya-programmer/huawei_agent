import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert noprofit_noloss(1500,1200)==False
        assert noprofit_noloss(100,100)==True
        assert noprofit_noloss(2000,5000)==False

if __name__ == '__main__':
    unittest.main()
