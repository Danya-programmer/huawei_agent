import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert rearrange_bigger(12)==21
        assert rearrange_bigger(10)==False
        assert rearrange_bigger(102)==120

if __name__ == '__main__':
    unittest.main()
