import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert max_sub_array_sum([-2, -3, 4, -1, -2, 1, 5, -3],8) == 5
        assert max_sub_array_sum([1, -2, 1, 1, -2, 1],6) == 2
        assert max_sub_array_sum([-1, -2, 3, 4, 5],5) == 3

if __name__ == '__main__':
    unittest.main()
