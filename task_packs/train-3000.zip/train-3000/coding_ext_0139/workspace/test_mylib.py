import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert reverse_words("python program")==("program python")
        assert reverse_words("java language")==("language java")
        assert reverse_words("indian man")==("man indian")

if __name__ == '__main__':
    unittest.main()
