import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert count_reverse_pairs(["julia", "best", "tseb", "for", "ailuj"])== '2'
        assert count_reverse_pairs(["geeks", "best", "for", "skeeg"]) == '1'
        assert count_reverse_pairs(["makes", "best", "sekam", "for", "rof"]) == '2' 

if __name__ == '__main__':
    unittest.main()
