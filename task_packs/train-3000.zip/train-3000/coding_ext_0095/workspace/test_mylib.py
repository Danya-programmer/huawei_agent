import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert binomial_probability(10, 5, 1.0/3) == 0.13656454808718185
        assert binomial_probability(11, 6, 2.0/4) == 0.2255859375
        assert binomial_probability(12, 7, 3.0/5) == 0.227030335488

if __name__ == '__main__':
    unittest.main()
