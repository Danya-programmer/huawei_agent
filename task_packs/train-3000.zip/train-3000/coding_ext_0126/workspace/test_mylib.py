import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert move_zero([1,0,2,0,3,4]) == [1,2,3,4,0,0]
        assert move_zero([2,3,2,0,0,4,0,5,0]) == [2,3,2,4,5,0,0,0,0]
        assert move_zero([0,1,0,1,1]) == [1,1,1,0,0]

if __name__ == '__main__':
    unittest.main()
