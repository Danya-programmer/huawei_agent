import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert bell_number(2)==2
        assert bell_number(10)==115975
        assert bell_number(56)==6775685320645824322581483068371419745979053216268760300

if __name__ == '__main__':
    unittest.main()
