import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert int_to_roman(1)==("I")
        assert int_to_roman(50)==("L")
        assert int_to_roman(4)==("IV")

if __name__ == '__main__':
    unittest.main()
