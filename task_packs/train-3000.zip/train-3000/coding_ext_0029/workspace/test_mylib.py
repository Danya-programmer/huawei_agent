import unittest
import mylib



METADATA = {}


def check(candidate):
    assert candidate(50) == 0
    assert candidate(78) == 2
    assert candidate(79) == 3
    assert candidate(100) == 3
    assert candidate(200) == 6
    assert candidate(4000) == 192
    assert candidate(10000) == 639
    assert candidate(100000) == 8026



class T(unittest.TestCase):
    def test_check(self):
        check(mylib.fizz_buzz)

if __name__ == '__main__':
    unittest.main()
