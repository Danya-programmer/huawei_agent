import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert decreasing_trend([-4,-3,-2,-1]) == True
        assert decreasing_trend([1,2,3]) == True
        assert decreasing_trend([3,2,1]) == False

if __name__ == '__main__':
    unittest.main()
