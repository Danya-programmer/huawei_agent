import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert next_Perfect_Square(35) == 36
        assert next_Perfect_Square(6) == 9
        assert next_Perfect_Square(9) == 16

if __name__ == '__main__':
    unittest.main()
