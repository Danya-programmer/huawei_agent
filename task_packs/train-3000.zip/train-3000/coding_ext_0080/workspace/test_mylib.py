import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert even_Power_Sum(2) == 1056
        assert even_Power_Sum(3) == 8832
        assert even_Power_Sum(1) == 32

if __name__ == '__main__':
    unittest.main()
