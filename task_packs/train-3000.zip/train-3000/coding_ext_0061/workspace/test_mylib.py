import unittest
import otherlib as mylib
from otherlib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert tuple_int_str((('333', '33'), ('1416', '55')))==((333, 33), (1416, 55))
        assert tuple_int_str((('999', '99'), ('1000', '500')))==((999, 99), (1000, 500))
        assert tuple_int_str((('666', '66'), ('1500', '555')))==((666, 66), (1500, 555))

if __name__ == '__main__':
    unittest.main()
