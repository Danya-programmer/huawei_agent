import unittest
import otherlib as mylib
from otherlib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert is_Diff (12345) == False
        assert is_Diff(1212112) == True
        assert is_Diff(1212) == False

if __name__ == '__main__':
    unittest.main()
