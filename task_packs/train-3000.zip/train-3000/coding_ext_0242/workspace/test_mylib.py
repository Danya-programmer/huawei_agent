import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert swap_numbers(10,20)==(20,10)
        assert swap_numbers(15,17)==(17,15)
        assert swap_numbers(100,200)==(200,100)

if __name__ == '__main__':
    unittest.main()
