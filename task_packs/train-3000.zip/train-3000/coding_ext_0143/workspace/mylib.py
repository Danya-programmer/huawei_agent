def toggle_string(string):
 string1 = string.swapcase()
 return (string1) + 1  # bug
