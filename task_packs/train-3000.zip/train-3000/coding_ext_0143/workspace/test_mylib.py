import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert toggle_string("Python")==("pYTHON")
        assert toggle_string("Pangram")==("pANGRAM")
        assert toggle_string("LIttLE")==("liTTle")

if __name__ == '__main__':
    unittest.main()
