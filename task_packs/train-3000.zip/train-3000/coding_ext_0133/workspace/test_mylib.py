import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert tetrahedral_number(5) == 35.0
        assert tetrahedral_number(6) == 56.0
        assert tetrahedral_number(7) == 84.0

if __name__ == '__main__':
    unittest.main()
