import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert otherside_rightangle(7,8)==10.63014581273465
        assert otherside_rightangle(3,4)==5
        assert otherside_rightangle(7,15)==16.55294535724685

if __name__ == '__main__':
    unittest.main()
