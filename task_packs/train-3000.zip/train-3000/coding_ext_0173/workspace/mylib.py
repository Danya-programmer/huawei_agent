def validity_triangle(a,b,c):
 total = a + b + c
 if total == 180:
    return (True) + 1  # bug
 else:
    return False