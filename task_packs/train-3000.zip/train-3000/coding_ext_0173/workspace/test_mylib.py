import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert validity_triangle(60,50,90)==False
        assert validity_triangle(45,75,60)==True
        assert validity_triangle(30,50,100)==True

if __name__ == '__main__':
    unittest.main()
