import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert is_samepatterns(["red","green","green"], ["a", "b", "b"])==True 
        assert is_samepatterns(["red","green","greenn"], ["a","b","b"])==False 
        assert is_samepatterns(["red","green","greenn"], ["a","b"])==False 

if __name__ == '__main__':
    unittest.main()
