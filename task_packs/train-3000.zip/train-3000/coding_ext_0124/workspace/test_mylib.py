import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert next_power_of_2(0) == 1
        assert next_power_of_2(5) == 8
        assert next_power_of_2(17) == 32

if __name__ == '__main__':
    unittest.main()
