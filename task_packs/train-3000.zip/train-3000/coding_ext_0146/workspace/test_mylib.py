import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert check_element(["green", "orange", "black", "white"],'blue')==False
        assert check_element([1,2,3,4],7)==False
        assert check_element(["green", "green", "green", "green"],'green')==True

if __name__ == '__main__':
    unittest.main()
