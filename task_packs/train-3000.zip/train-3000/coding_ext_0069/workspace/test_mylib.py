import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert square_Sum(2) == 10
        assert square_Sum(3) == 35
        assert square_Sum(4) == 84

if __name__ == '__main__':
    unittest.main()
