import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert frequency_Of_Smallest(5,[1,2,3,4,3]) == 1
        assert frequency_Of_Smallest(7,[3,1,2,5,6,2,3]) == 1
        assert frequency_Of_Smallest(7,[3,3,6,3,7,4,9]) == 3

if __name__ == '__main__':
    unittest.main()
