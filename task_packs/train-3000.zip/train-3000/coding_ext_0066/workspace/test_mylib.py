import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert min_of_three(10,20,0)==0
        assert min_of_three(19,15,18)==15
        assert min_of_three(-10,-20,-30)==-30

if __name__ == '__main__':
    unittest.main()
