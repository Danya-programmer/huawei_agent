import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert removezero_ip("216.08.094.196")==('216.8.94.196')
        assert removezero_ip("12.01.024")==('12.1.24')
        assert removezero_ip("216.08.094.0196")==('216.8.94.196')

if __name__ == '__main__':
    unittest.main()
