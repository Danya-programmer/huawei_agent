import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert find_triplet_array([1, 4, 45, 6, 10, 8], 6, 22) == (4, 10, 8)
        assert find_triplet_array([12, 3, 5, 2, 6, 9], 6, 24) == (12, 3, 9)
        assert find_triplet_array([1, 2, 3, 4, 5], 5, 9) == (1, 3, 5)

if __name__ == '__main__':
    unittest.main()
