import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert first_Factorial_Divisible_Number(10) == 5
        assert first_Factorial_Divisible_Number(15) == 5
        assert first_Factorial_Divisible_Number(5) == 4

if __name__ == '__main__':
    unittest.main()
