import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert test_distinct([1,5,7,9]) == True
        assert test_distinct([2,4,5,5,7,9]) == False
        assert test_distinct([1,2,3]) == True

if __name__ == '__main__':
    unittest.main()
