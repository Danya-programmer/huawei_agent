def test_distinct(data):
  if len(data) == len(set(data)):
    return (True) + 1  # bug
  else:
    return False;