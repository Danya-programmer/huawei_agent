import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert math.isclose(harmonic_sum(7), 2.5928571428571425, rel_tol=0.001)
        assert math.isclose(harmonic_sum(4), 2.083333333333333, rel_tol=0.001)
        assert math.isclose(harmonic_sum(19), 3.547739657143682, rel_tol=0.001)

if __name__ == '__main__':
    unittest.main()
