import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert check_identical([(10, 4), (2, 5)], [(10, 4), (2, 5)]) == True
        assert check_identical([(1, 2), (3, 7)], [(12, 14), (12, 45)]) == False
        assert check_identical([(2, 14), (12, 25)], [(2, 14), (12, 25)]) == True

if __name__ == '__main__':
    unittest.main()
