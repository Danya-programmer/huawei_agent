import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert average_Odd(9) == 5
        assert average_Odd(5) == 3
        assert average_Odd(11) == 6

if __name__ == '__main__':
    unittest.main()
