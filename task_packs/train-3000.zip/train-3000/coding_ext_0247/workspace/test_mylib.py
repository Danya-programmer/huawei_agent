import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert multiply_num((8, 2, 3, -1, 7))==-67.2
        assert multiply_num((-10,-20,-30))==-2000.0
        assert multiply_num((19,15,18))==1710.0

if __name__ == '__main__':
    unittest.main()
