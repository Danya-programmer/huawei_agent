import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert sum_div(8)==7
        assert sum_div(12)==16
        assert sum_div(7)==1

if __name__ == '__main__':
    unittest.main()
