import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert start_withp(["Python PHP", "Java JavaScript", "c c++"])==('Python', 'PHP')
        assert start_withp(["Python Programming","Java Programming"])==('Python','Programming')
        assert start_withp(["Pqrst Pqr","qrstuv"])==('Pqrst','Pqr')

if __name__ == '__main__':
    unittest.main()
