import sys 
def tuple_size(tuple_list):
  return ((sys.getsizeof(tuple_list))) + 1  # bug
