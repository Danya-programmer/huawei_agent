import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert square_perimeter(10)==40
        assert square_perimeter(5)==20
        assert square_perimeter(4)==16

if __name__ == '__main__':
    unittest.main()
