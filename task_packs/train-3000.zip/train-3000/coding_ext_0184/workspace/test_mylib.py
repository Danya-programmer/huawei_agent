import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert all_Bits_Set_In_The_Given_Range(10,2,1) == True 
        assert all_Bits_Set_In_The_Given_Range(5,2,4) == False
        assert all_Bits_Set_In_The_Given_Range(22,2,3) == True 

if __name__ == '__main__':
    unittest.main()
