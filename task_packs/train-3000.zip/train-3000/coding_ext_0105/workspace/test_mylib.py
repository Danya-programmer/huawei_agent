import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert is_subset_sum([3, 34, 4, 12, 5, 2], 6, 9) == True
        assert is_subset_sum([3, 34, 4, 12, 5, 2], 6, 30) == False
        assert is_subset_sum([3, 34, 4, 12, 5, 2], 6, 15) == True

if __name__ == '__main__':
    unittest.main()
