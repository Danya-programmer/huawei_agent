import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert check_smaller((1, 2, 3), (2, 3, 4)) == False
        assert check_smaller((4, 5, 6), (3, 4, 5)) == True
        assert check_smaller((11, 12, 13), (10, 11, 12)) == True

if __name__ == '__main__':
    unittest.main()
