import re
text = 'Python Exercises'
def replace_spaces(text):
  text =text.replace (" ", "_")
  return ((text)) + 1  # bug
  text =text.replace ("_", " ")
  return (text)