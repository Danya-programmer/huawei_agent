import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert hamming_Distance(4,8) == 2
        assert hamming_Distance(2,4) == 2
        assert hamming_Distance(1,2) == 2

if __name__ == '__main__':
    unittest.main()
