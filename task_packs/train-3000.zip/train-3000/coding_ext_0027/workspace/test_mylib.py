import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert text_uppercase_lowercase("AaBbGg")==('Found a match!')
        assert text_uppercase_lowercase("aA")==('Not matched!')
        assert text_uppercase_lowercase("PYTHON")==('Not matched!')

if __name__ == '__main__':
    unittest.main()
