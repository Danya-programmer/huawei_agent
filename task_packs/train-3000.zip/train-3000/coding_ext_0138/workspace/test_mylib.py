import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert long_words(3,"python is a programming language")==['python','programming','language']
        assert long_words(2,"writing a program")==['writing','program']
        assert long_words(5,"sorting list")==['sorting']

if __name__ == '__main__':
    unittest.main()
