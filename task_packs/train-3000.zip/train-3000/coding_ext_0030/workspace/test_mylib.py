import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert volume_cube(3)==27
        assert volume_cube(2)==8
        assert volume_cube(5)==125

if __name__ == '__main__':
    unittest.main()
