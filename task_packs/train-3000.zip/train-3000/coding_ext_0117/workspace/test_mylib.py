import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert remove_Occ("hello","l") == "heo"
        assert remove_Occ("abcda","a") == "bcd"
        assert remove_Occ("PHP","P") == "H"

if __name__ == '__main__':
    unittest.main()
