import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert ap_sum(1,5,2)==25
        assert ap_sum(2,6,4)==72
        assert ap_sum(1,4,5)==34

if __name__ == '__main__':
    unittest.main()
