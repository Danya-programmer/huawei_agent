import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert max_occurrences([1,2,3,1,2,3,12,4,2]) ==  2
        assert max_occurrences([1,2,6,7,0,1,0,1,0]) == 1,0
        assert max_occurrences([1,2,3,1,2,4,1]) == 1

if __name__ == '__main__':
    unittest.main()
