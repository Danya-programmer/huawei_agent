import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert get_max_sum(60) == 106
        assert get_max_sum(10) == 12
        assert get_max_sum(2) == 2

if __name__ == '__main__':
    unittest.main()
