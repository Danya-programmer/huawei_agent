import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert difference(3) == 30
        assert difference(5) == 210
        assert difference(2) == 6

if __name__ == '__main__':
    unittest.main()
