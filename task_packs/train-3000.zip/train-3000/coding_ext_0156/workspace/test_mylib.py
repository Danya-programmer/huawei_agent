import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert Split([1,2,3,4,5,6]) == [1,3,5]
        assert Split([10,11,12,13]) == [11,13]
        assert Split([7,8,9,1]) == [7,9,1]

if __name__ == '__main__':
    unittest.main()
