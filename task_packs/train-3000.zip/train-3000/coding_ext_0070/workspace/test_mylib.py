import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert slope(4,2,2,5) == -1.5
        assert slope(2,4,4,6) == 1
        assert slope(1,2,4,2) == 0

if __name__ == '__main__':
    unittest.main()
