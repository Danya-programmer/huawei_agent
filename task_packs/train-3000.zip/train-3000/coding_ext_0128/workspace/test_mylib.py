import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert area_polygon(4,20)==400.00000000000006
        assert area_polygon(10,15)==1731.1969896610804
        assert area_polygon(9,7)==302.90938549487214

if __name__ == '__main__':
    unittest.main()
