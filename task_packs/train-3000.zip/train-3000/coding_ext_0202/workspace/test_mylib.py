import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert is_nonagonal(10) == 325
        assert is_nonagonal(15) == 750
        assert is_nonagonal(18) == 1089

if __name__ == '__main__':
    unittest.main()
