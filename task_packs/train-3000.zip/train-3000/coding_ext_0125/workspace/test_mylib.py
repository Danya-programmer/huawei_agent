import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert replace_blank("hello people",'@')==("hello@people")
        assert replace_blank("python program language",'$')==("python$program$language")
        assert replace_blank("blank space","-")==("blank-space")

if __name__ == '__main__':
    unittest.main()
