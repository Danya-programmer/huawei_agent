import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert check("01010101010") == "Yes"
        assert check("name0") == "No"
        assert check("101") == "Yes"

if __name__ == '__main__':
    unittest.main()
