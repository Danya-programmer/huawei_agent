import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert check(70) == False
        assert check(23) == False
        assert check(73) == True

if __name__ == '__main__':
    unittest.main()
