import unittest
import mylib
from mylib import *  # noqa: F401,F403

class T(unittest.TestCase):
    def test_cases(self):
        assert surfacearea_cone(5,12)==282.7433388230814
        assert surfacearea_cone(10,15)==880.5179353159282
        assert surfacearea_cone(19,17)==2655.923961165254

if __name__ == '__main__':
    unittest.main()
